package com.cg.ibs.investment.bean;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

public class AccountHoldingBean {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long aHId;

	@ManyToOne
	private CustomerBean customer;
	@ManyToOne
	private AccountBean account;
	@Enumerated(EnumType.STRING)
	private AccountHoldingType type;

}
