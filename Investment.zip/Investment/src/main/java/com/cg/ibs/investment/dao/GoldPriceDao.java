package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.cg.ibs.investment.bean.GoldPrice;

public interface GoldPriceDao {
	GoldPrice addGoldPrice(GoldPrice price);

	GoldPrice getPriceByDate(LocalDate dt);

}
