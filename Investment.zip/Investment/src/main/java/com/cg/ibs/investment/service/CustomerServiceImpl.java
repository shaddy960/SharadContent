package com.cg.ibs.investment.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.CustomerBean;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.bean.SilverPrice;
import com.cg.ibs.investment.bean.TransactionBean;
import com.cg.ibs.investment.dao.AccountDao;
import com.cg.ibs.investment.dao.AccountDaoImpl;
import com.cg.ibs.investment.dao.CustomerDao;
import com.cg.ibs.investment.dao.CustomerDaoImpl;
import com.cg.ibs.investment.dao.GoldPriceDao;
import com.cg.ibs.investment.dao.GoldPriceDaoImpl;
import com.cg.ibs.investment.dao.InvestmentDao;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.dao.SilverPriceDao;
import com.cg.ibs.investment.dao.SilverPriceDaoImpl;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.util.JPAUtil;

public class CustomerServiceImpl implements CustomerService {
	private static final Logger log = Logger.getLogger(CustomerServiceImpl.class);
	@Override
	public HashMap<Integer, BankMutualFund> viewMFPlans() throws IBSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double viewGoldPrice() throws IBSException {
		GoldPriceDao dao = new GoldPriceDaoImpl();
		Double price=dao.viewGoldPrice();		
		return price;
	}

	@Override
	public double viewSilverPrice() throws IBSException {
		SilverPriceDao dao=new SilverPriceDaoImpl();
		Double price=dao.viewSilverPrice();		
		return price;
		
				}
			
			

	@Override
	public void buyGold(double gunits, String userId) throws IBSException {
		EntityTransaction txn = JPAUtil.getTransaction();
		CustomerDao cs = new CustomerDaoImpl();
		BigInteger uci = cs.getUciByUserId(userId);
		InvestmentDao invdao= new InvestmentDaoImpl();
		InvestmentBean inv=invdao.getInvestmentByUci(uci);
		
		if(inv !=null) {
		Double balance= Double.parseDouble(inv.getAccount().getBalance().toString());
		if(balance>gunits*viewGoldPrice()) {		
			txn.begin();
			inv.setGoldunits(gunits+inv.getGoldunits());
			AccountBean acc= inv.getAccount();
			MathContext mc = new MathContext(2);
			BigDecimal amount=inv.getAccount().getBalance().subtract(new BigDecimal(gunits*viewGoldPrice()),mc );
			acc.setBalance(amount);
			Set<TransactionBean> tBeans=inv.getAccount().getTransaction();
			TransactionBean tBean= new TransactionBean();
		    tBean.setTransactionId((int)Math.round(Math.random()*10000));
		    tBean.setTransactionAmount(amount);
		    tBean.setTransactionDate(LocalDateTime.now());
		    tBean.setAccountNumber(inv.getAccount().getAccNo());
		    tBean.setTransactionDescription(transactionDescription);
			
			
			txn.commit();
		}}
		
		
		
	}

	@Override
	public void sellGold(double gunits, String userId) throws IBSException {
	
		
	}

	@Override
	public void buySilver(double sunits, String userId) throws IBSException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sellSilver(double sunits, String userId) throws IBSException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void investMF(double mfAmount, String userId, Integer mfId) throws IBSException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdrawMF(String userId, MutualFund mutualFund) throws IBSException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public InvestmentBean viewInvestments(String userId) throws IBSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validateCustomer(String userId, String password)  {
		CustomerDao cs = new CustomerDaoImpl();
		BigInteger uci = cs.getUciByUserId(userId);
		CustomerBean customer = cs.getCustByUci(uci);

		if (customer != null && userId.equals(customer.getUserId())) {

			String correctPassword = customer.getPassword();
			if (password.equals(correctPassword)) {
				log.info("Customer Validated Successfully");
				return true;
			}
		}
		return false;
	}

	@Override
	public TreeSet<TransactionBean> getTransactions(String userId) throws IBSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<AccountBean> getAccountList(String userId) throws IBSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void linkMyAccount(BigInteger accountNumber, String userId) throws IBSException {
		// TODO Auto-generated method stub
		
	}
	

	

}
