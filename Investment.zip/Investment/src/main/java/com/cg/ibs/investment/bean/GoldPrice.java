package com.cg.ibs.investment.bean;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GoldPrice {
	@Id
	private LocalDate date;
	@Column(precision = 2)
	private Double goldPrice;
	public GoldPrice() {
		super();
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public Double getGoldPrice() {
		return goldPrice;
	}
	public void setGoldPrice(Double goldPrice) {
		this.goldPrice = goldPrice;
	}
	

}