package com.cg.ibs.investment.bean;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GoldPrice {
	@Id
	private LocalDate date;
	@Column(precision = 2)
	private Double goldPrice;

}