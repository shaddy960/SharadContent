package com.cg.ibs.investment.bean;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

public class InvestmentBean {
	@Id
	private String UCI;
	@OneToOne
	@JoinColumn(name = "UCI")
	@MapsId
	private CustomerBean customer;

	@Column(precision = 2)
	private Double goldunits;

	@Column(precision = 2)
	private Double silverunits;

	@Column(precision = 2)
	private Double balance;
	@OneToMany
	private Set<MutualFund> funds;
	@OneToOne
	private AccountBean account;

	public InvestmentBean() {
		super();
	}

	public String getUCI() {
		return UCI;
	}

	public void setUCI(String uCI) {
		UCI = uCI;
	}

	public CustomerBean getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerBean customer) {
		this.customer = customer;
	}

	public Double getGoldunits() {
		return goldunits;
	}

	public void setGoldunits(Double goldunits) {
		this.goldunits = goldunits;
	}

	public Double getSilverunits() {
		return silverunits;
	}

	public void setSilverunits(Double silverunits) {
		this.silverunits = silverunits;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Set<MutualFund> getFunds() {
		return funds;
	}

	public void setFunds(Set<MutualFund> funds) {
		this.funds = funds;
	}

	public AccountBean getAccount() {
		return account;
	}

	public void setAccount(AccountBean account) {
		this.account = account;
	}

}
