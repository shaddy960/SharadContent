package com.cg.ibs.investment.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Transaction")
public class TransactionBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "TRANS_ID", nullable = false, length = 10)
	private Integer transactionId;
	@Column(name = "TRANS_TYPE", nullable = false, length = 20)
	@Enumerated(EnumType.STRING)
	private TransactionType transactionType;
	@Column(name = "TRANS_DATE_TIME", nullable = false, length = 20)
	private LocalDateTime transactionDate;
	@Column(name = "AMOUNT", nullable = false, length = 10)
	private BigDecimal transactionAmount;
	@Column(name = "TRANS_MODE", nullable = false, length = 20)
	@Enumerated(EnumType.STRING)
	private TransactionMode transactionMode;
	@Column(name = "ACC_NO", nullable = false, length = 11)
	private BigInteger accountNumber;
	@Column(name = "TRANS_DESC", nullable = false, length = 40)
	private String transactionDescription;

}