package com.cg.ibs.investment.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.util.JPAUtil;

public class MutualFundDaoImpl implements MutualFundDao {
	private EntityManager entityManager;

	public MutualFundDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}
	@Override
	public MutualFund addMutualFund(MutualFund mf) {
		entityManager.persist(mf);
		return mf;
	}

	@Override
	public MutualFund updateMutualFund(MutualFund mf) {
		return entityManager.merge(mf);
	}

	@Override
	public MutualFund getMutualFundById(Integer mfId) {
		return entityManager.find(MutualFund.class, mfId);
	}

	@Override
	public List<MutualFund> getAllMutualFunds() {
		CriteriaQuery<MutualFund> query = entityManager.getCriteriaBuilder().createQuery(MutualFund.class);
		Root<MutualFund> root = query.from(MutualFund.class);
		query.select(root);

		return entityManager.createQuery(query).getResultList();
	}

	@Override
	public boolean removeMutualFund(Integer mfId) {
		boolean isDeleted = false;
		MutualFund bean = getMutualFundById(mfId);
		if (null != bean) {
			entityManager.remove(bean);
			isDeleted = true;
		}
		return isDeleted;
	}

}
