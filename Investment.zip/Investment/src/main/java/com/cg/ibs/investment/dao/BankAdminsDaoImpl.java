package com.cg.ibs.investment.dao;

import javax.persistence.EntityManager;

import com.cg.ibs.investment.bean.BankAdmins;
import com.cg.ibs.investment.util.JPAUtil;

public class BankAdminsDaoImpl  implements BankAdminsDao{
	private EntityManager entityManager;

	public BankAdminsDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}
	@Override
	public BankAdmins addBankAdmins(BankAdmins bank) {
		entityManager.persist(bank);
		return bank;
	}

	@Override
	public BankAdmins getBankById(String id) {
		return entityManager.find(BankAdmins.class, id);
	}

}
