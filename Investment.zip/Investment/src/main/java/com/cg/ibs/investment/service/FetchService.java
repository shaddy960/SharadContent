package com.cg.ibs.investment.service;

import java.math.BigInteger;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.CustomerBean;
import com.cg.ibs.investment.dao.AccountDao;
import com.cg.ibs.investment.dao.AccountDaoImpl;
import com.cg.ibs.investment.dao.CustomerDao;
import com.cg.ibs.investment.dao.CustomerDaoImpl;

public class FetchService {
	private AccountDao accountDao;
	private CustomerDao custDao;
	
	public FetchService() {
		accountDao=new AccountDaoImpl();
		custDao=new CustomerDaoImpl();
	}
	
	public CustomerBean getCustomerByUci(BigInteger uci) {
		return custDao.getCustByUci(uci);
	}
	public AccountBean getAccByAccNum(BigInteger accNo) {
		return accountDao.getAccountByAccNo(accNo);
	}
}
