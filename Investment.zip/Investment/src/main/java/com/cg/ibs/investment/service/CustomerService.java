package com.cg.ibs.investment.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.investment.bean.CustomerBean;

public interface CustomerService {

	CustomerBean addCustomer(CustomerBean cust);
	CustomerBean updateCustomer(CustomerBean cust);
	CustomerBean getCustomerByUci(BigInteger uci);
	List<CustomerBean> getAllCustomers();
	boolean removeCustomer(BigInteger uci);

}
