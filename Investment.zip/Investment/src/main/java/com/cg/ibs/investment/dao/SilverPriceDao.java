package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.cg.ibs.investment.bean.SilverPrice;

public interface SilverPriceDao {

	SilverPrice addSilverPrice(SilverPrice price);

	
	SilverPrice getPriceByDate(LocalDate dt);

	

}
