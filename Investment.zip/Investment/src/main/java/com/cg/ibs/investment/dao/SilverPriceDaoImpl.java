package com.cg.ibs.investment.dao;

import java.time.LocalDate;

import javax.persistence.EntityManager;

import com.cg.ibs.investment.bean.SilverPrice;
import com.cg.ibs.investment.util.JPAUtil;

public class SilverPriceDaoImpl implements SilverPriceDao {
	private EntityManager entityManager;

	public SilverPriceDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}
	@Override
	public SilverPrice addSilverPrice(SilverPrice price) {
		entityManager.persist(price);
		return price;
	}

	@Override
	public SilverPrice getPriceByDate(LocalDate dt) {
		return entityManager.find(SilverPrice.class, dt);
	}

}
