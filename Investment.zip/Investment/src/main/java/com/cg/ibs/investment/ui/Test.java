package com.cg.ibs.investment.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.AccountHoldingBean;
import com.cg.ibs.investment.bean.AccountHoldingType;
import com.cg.ibs.investment.bean.AccountStatus;
import com.cg.ibs.investment.bean.AccountType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.CustomerBean;
import com.cg.ibs.investment.bean.Gender;
import com.cg.ibs.investment.bean.GoldPrice;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.bean.SilverPrice;
import com.cg.ibs.investment.dao.AccountDao;
import com.cg.ibs.investment.dao.AccountDaoImpl;
import com.cg.ibs.investment.service.AdditionService;
import com.cg.ibs.investment.service.CSIMPL;
import com.cg.ibs.investment.service.FetchService;
import com.cg.ibs.investment.util.JPAUtil;

public class Test {

	public static void main(String[] args) {
		AdditionService as=new AdditionService();
		FetchService fs=new FetchService();
		GoldPrice gp=new GoldPrice();
		gp.setDate(LocalDate.now());
		gp.setGoldPrice(new Double(3000.00));
		as.addGoldPrice(gp);
		SilverPrice sp=new SilverPrice();
		sp.setDate(LocalDate.now());
		sp.setSilverPrice(new Double(300.00));
		as.addSilverPrice(sp);
		
		
		
		
	}

}
