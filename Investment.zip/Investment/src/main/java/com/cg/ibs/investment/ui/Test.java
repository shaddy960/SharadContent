package com.cg.ibs.investment.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

import javax.persistence.EntityManager;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.AccountHoldingBean;
import com.cg.ibs.investment.bean.AccountHoldingType;
import com.cg.ibs.investment.bean.AccountStatus;
import com.cg.ibs.investment.bean.AccountType;
import com.cg.ibs.investment.bean.CustomerBean;
import com.cg.ibs.investment.bean.Gender;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.dao.AccountDao;
import com.cg.ibs.investment.dao.AccountDaoImpl;
import com.cg.ibs.investment.service.AdditionService;
import com.cg.ibs.investment.service.CustomerServiceImpl;
import com.cg.ibs.investment.service.FetchService;
import com.cg.ibs.investment.util.JPAUtil;

public class Test {

	public static void main(String[] args) {
		
		
		FetchService fs=new FetchService();
		CustomerBean cs=fs.getCustomerByUci(new BigInteger("1234123412341234"));
		
		System.out.println(cs.getUci());
		AccountBean acc=fs.getAccByAccNum(new BigInteger("123412341234"));
		
		System.out.println(acc);
		AdditionService as=new AdditionService();
		AccountHoldingBean hold=new AccountHoldingBean();
		hold.setAccount(acc);
		hold.setaHId(new Long(5050));
		hold.setCustomer(cs);
		hold.setType(AccountHoldingType.INDIVIDUAL);
		as.addAccHold(hold);
	}

}
