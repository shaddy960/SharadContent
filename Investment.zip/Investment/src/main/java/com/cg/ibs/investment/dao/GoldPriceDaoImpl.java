package com.cg.ibs.investment.dao;

import java.time.LocalDate;

import javax.persistence.EntityManager;

import com.cg.ibs.investment.bean.GoldPrice;
import com.cg.ibs.investment.util.JPAUtil;

public class GoldPriceDaoImpl implements GoldPriceDao{
	private EntityManager entityManager;

	public GoldPriceDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}
	@Override
	public GoldPrice addGoldPrice(GoldPrice price) {
		entityManager.persist(price);
		return price;
	}

	@Override
	public GoldPrice getPriceByDate(LocalDate dt) {
		return entityManager.find(GoldPrice.class, dt);
	}

}
