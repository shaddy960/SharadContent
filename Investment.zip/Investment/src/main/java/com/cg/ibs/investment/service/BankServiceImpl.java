package com.cg.ibs.investment.service;

import org.apache.log4j.Logger;

import com.cg.ibs.investment.bean.BankAdmins;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.dao.BankAdminsDao;
import com.cg.ibs.investment.dao.BankAdminsDaoImpl;
import com.cg.ibs.investment.dao.GoldPriceDao;
import com.cg.ibs.investment.dao.GoldPriceDaoImpl;
import com.cg.ibs.investment.dao.SilverPriceDao;
import com.cg.ibs.investment.dao.SilverPriceDaoImpl;
import com.cg.ibs.investment.exception.IBSException;

public class BankServiceImpl implements BankService {
	static Logger log = Logger.getLogger(BankServiceImpl.class.getName());
	// Declaring an object of Bank DAO

	// To check whether Gold/Silver price is valid
	public boolean isValidGoldSilver(double price) {
		return false;
	}

	// To check whether Mutual Fund is valid
	public boolean isValidMutualFund(BankMutualFund mutualFund) {
		return false;

	}

	// To update Gold price
	public boolean updateGoldPrice(Double goldPrice) throws IBSException {
		GoldPriceDao dao = new GoldPriceDaoImpl();
		return dao.addGoldPrice(goldPrice);

	}

	// To update Silver price
	public boolean updateSilverPrice(double silverPrice) throws IBSException {
		SilverPriceDao dao = new SilverPriceDaoImpl();
		return dao.addSilverPrice(silverPrice);

	}

	// To validate login details of Bank representative
	@Override
	public boolean validateBank(String userId, String password) throws IBSException {
		BankAdminsDao daoObject = new BankAdminsDaoImpl();

		BankAdmins cs = daoObject.getBankById(userId);
		if (cs != null && userId.equals(cs.getAdminId())) {

			String correctPassword = cs.getPassword();
			if (password.equals(correctPassword)) {
				return true;

			}
		}
		log.error("Bank validated by service");
		return false;

	}

	@Override
	public void addMF(BankMutualFund mutualFund) throws IBSException {

	}
}