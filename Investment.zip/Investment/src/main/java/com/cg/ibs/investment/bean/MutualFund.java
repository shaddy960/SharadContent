package com.cg.ibs.investment.bean;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class MutualFund {
	@Id
	private Integer mfid;
	@OneToOne
	private BankMutualFund bankMutualFund;
	@Column(precision = 2)		
	private Double mfUnits;
	@Column(precision = 2)
	private Double mfAmount;		
	private LocalDate openingDate;	
	private LocalDate closingDate;	
	private Boolean status;
}
