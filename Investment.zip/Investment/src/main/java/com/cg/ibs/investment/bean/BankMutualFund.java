package com.cg.ibs.investment.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BankMutualFund {
	@Id
	private Integer mfPlanId; // Declaring Id of a Mutual fund
	private String title; // Declaring Title of a Mutual fund
	@Column(precision = 2)
	private Double nav;
}
