package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.investment.bean.BankAdmins;

public interface BankAdminsDao {
	BankAdmins addBankAdmins(BankAdmins id);

	BankAdmins getBankById(String id);

}
