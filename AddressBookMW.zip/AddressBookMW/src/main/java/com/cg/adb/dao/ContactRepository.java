package com.cg.adb.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.adb.entity.ContactEntity;
import com.cg.adb.model.GroupStatistics;

@Repository
public interface ContactRepository extends JpaRepository<ContactEntity,Long>{

	List<ContactEntity> findAllByFirstName(String firstName);
	List<ContactEntity> findAllByLastName(String lastName);
	List<ContactEntity> findAllByMiddleName(String middleName);
	
	ContactEntity findByMobileNumber(String mobileNumber);
	ContactEntity findByMailId(String mailId);
	
	@Query("select c from ContactEntity c inner join c.group g where g.groupId=:groupId")
	List<ContactEntity> findAllByGroupId(Long groupId);

	@Query("select new com.cg.adb.model.GroupStatistics(g.groupName,COUNT(c)) from ContactEntity c full join c.group g group by g.groupName")
	List<GroupStatistics> findGroupCount();
	

}
