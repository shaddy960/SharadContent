package com.cg.adb.service;

import java.util.List;

import com.cg.adb.exception.AdbException;
import com.cg.adb.model.ContactModel;
import com.cg.adb.model.GroupModel;
import com.cg.adb.model.GroupStatistics;

public interface ContactService {
	ContactModel add(ContactModel group) throws AdbException;
	ContactModel save(ContactModel group) throws AdbException;
	void delete(Long contactId) throws AdbException;
	ContactModel findById(Long contactId);
	List<ContactModel> findAll();
	List<GroupStatistics> findGroupCount();
}
