package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.cg.ibs.investment.bean.Customer;

@Repository("cs")
public class CustomerDaoImpl implements CustomerDao {
	@PersistenceContext
	private EntityManager entityManager;

	public Customer addCustomer(Customer cust) {
		entityManager.persist(cust);
		return cust;
	}

	public Customer updateCustomer(Customer cust) {
		return entityManager.merge(cust);
	}

	public Customer getCustByUci(BigInteger uci) {
		return entityManager.find(Customer.class, uci);
	}

	public List<Customer> getAllCustomers() {
		CriteriaQuery<Customer> query = entityManager.getCriteriaBuilder().createQuery(Customer.class);
		Root<Customer> CustomerRoot = query.from(Customer.class);
		query.select(CustomerRoot);

		return entityManager.createQuery(query).getResultList();
	}

	public boolean removeCustomer(BigInteger uci) {
		boolean isDeleted = false;
		Customer Customer = getCustByUci(uci);
		if (null != Customer) {
			entityManager.remove(Customer);
			isDeleted = true;
		}
		return isDeleted;
	}

	public BigInteger getUciByUserId(String userId) {

		TypedQuery<Customer> query = (TypedQuery<Customer>) entityManager.createNamedQuery("getUciByUserId",
				Customer.class);
		query.setParameter(1, userId);
		BigInteger uci = null;
		try {
			Customer cs = query.getSingleResult();
			uci = cs.getUci();
		} catch (NoResultException e) {

		}

		return uci;
	}

}
