package com.cg.ibs.investment.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.InvestmentTransaction;
import com.cg.ibs.investment.bean.MFType;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.bean.ViewInvestmentBean;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.model.DirectData;
import com.cg.ibs.investment.model.MutualView;
import com.cg.ibs.investment.model.SipData;
import com.cg.ibs.investment.model.Statement;
import com.cg.ibs.investment.model.TransactionView;
import com.cg.ibs.investment.model.Units;
import com.cg.ibs.investment.model.User;
import com.cg.ibs.investment.model.WithdrawDir;

import com.cg.ibs.investment.service.CustomerService;

@RestController
@CrossOrigin
@RequestMapping("/customer")
public class CustomerController {
	private String userId = "user1";

	@Autowired
	private CustomerService customerService;

	/*
	 * @RequestMapping("/customer") public ModelAndView showDeptsHome() { return new
	 * ModelAndView("customerLogin"); }
	 */
	@PostMapping("/login")
	public ResponseEntity<Statement> customerLogin(@RequestBody User user) {
		System.out.println(user.getUserId() + user.getPassword());
		ResponseEntity<Statement> responseEntity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
		try {
			if (customerService.validateCustomer(user.getUserId(), user.getPassword())) {
				statement.setBool(true);
				statement.setMsg("User Logged in");
				responseEntity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
				// customerService.autoSip(userId);
			} else {
				statement.setBool(false);
				statement.setMsg("No Such User exists");
				responseEntity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);

			}
		} catch (IBSException e) {
			statement.setBool(false);
			statement.setMsg(e.getMessage());
			responseEntity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);

		}

		return responseEntity;
	}

	@GetMapping("/viewMyInvestment")
	public ResponseEntity<ViewInvestmentBean> viewMyInvestments() {

		ViewInvestmentBean invBean = new ViewInvestmentBean();
		List<MutualView> dirset = new ArrayList<MutualView>();
		List<MutualView> sipset = new ArrayList<MutualView>(); 
		Double amt=0.0;
		try {
			InvestmentBean bean = customerService.viewInvestments("user1");
			System.out.println(bean.getUCI());
			invBean.setUci(bean.getUCI());
			invBean.setAccountNumber(bean.getAccount().getAccNo());
			invBean.setGoldUnits(bean.getGoldunits());
			invBean.setBalance(bean.getAccount().getBalance());
			invBean.setSilverUnits(bean.getSilverunits());
			invBean.setGoldAsset(bean.getGoldunits()*customerService.viewGoldPrice());
			invBean.setSilverAsset(bean.getSilverunits()*customerService.viewSilverPrice());

			
			for (MutualFund mf : bean.getFunds()) {
			MutualView view=new MutualView();
				if (mf.getType() == MFType.DIRECT && mf.getStatus()==true) {
					view.setBuyDate(mf.getBuyDate());
					view.setMfAmount(mf.getMfUnits()*mf.getBankMutualFund().getNav());
					view.setMfUnits(mf.getMfUnits());
					view.setPlanName(mf.getBankMutualFund().getTitle());
					view.setFolioNumber(mf.getFolioNumber());
					amt=amt+mf.getMfUnits()*mf.getBankMutualFund().getNav();
					dirset.add(view);
					
				} else if(mf.getType()==MFType.SIP && mf.getStatus()==true) {
					view.setBuyDate(mf.getBuyDate());
					view.setMfAmount(mf.getMfAmount());
					view.setMfUnits(mf.getMfUnits());
					view.setPlanName(mf.getBankMutualFund().getTitle());
					view.setFolioNumber(mf.getFolioNumber());
					view.setDuration(mf.getDuration());
					view.setClosingDate(mf.getClosingDate());
					view.setFrequency(mf.getFrequency());
					view.setInstallments(mf.getInstallments());
					view.setNextInstallDate(mf.getNextInstallDate());
					view.setOpeningDate(mf.getOpeningDate());
					view.setStatus(mf.getStatus());
					amt=amt+mf.getMfUnits()*mf.getBankMutualFund().getNav();
					sipset.add(view);
				}
			}
			invBean.setDirFunds(dirset);
			invBean.setSipfunds(sipset);
			invBean.setMfAssest(amt);
			
			 
		} catch (IBSException e) {

		}
		return new ResponseEntity<ViewInvestmentBean>(invBean, HttpStatus.OK);
	}

	@PostMapping("/directInvest")
	public ResponseEntity<Statement> investDirect(@RequestBody DirectData data) {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
		try {
			statement.setMsg("Direct Investment Bought successfully");
			statement.setBool(true);
			customerService.investDirMF(data.getMfAmount(), userId, data.getMfPlanId());
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		} catch (IBSException e) {
			statement.setBool(false);
			statement.setMsg((e.getMessage()));
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		}
		return entity;
	}

	@PostMapping("/buyGold")
	public ResponseEntity<Statement> buyGold(@RequestBody Units gUnits) {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement st = new Statement();
		try {

			customerService.buyGold(gUnits.getUnits(), gUnits.getUserId());

			st.setBool(true);
			st.setMsg("You successfully completed your gold purchase");
			entity = new ResponseEntity<Statement>(st, HttpStatus.OK);
		} catch (IBSException e) {
			st.setBool(false);
			st.setMsg(e.getMessage());
			entity = new ResponseEntity<Statement>(st, HttpStatus.BAD_REQUEST);
		}
		return entity;
	}

	@PostMapping("/buySilver")
	public ResponseEntity<Statement> buySilver(@RequestBody Units sUnits) {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
		try {
			customerService.buySilver(sUnits.getUnits(), userId);
			statement.setMsg("You successfully completed your silver purchase");
			statement.setBool(true);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		} catch (IBSException e) {
			statement.setMsg(e.getMessage());
			statement.setBool(false);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);
		}
		return entity;
	}

	@PostMapping("/sellGold")
	public ResponseEntity<Statement> sellGold(@RequestBody Units gUnits) {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
		try {
			customerService.sellGold(gUnits.getUnits(), userId);
			statement.setMsg("You successfully sold your gold units");
			statement.setBool(true);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		} catch (IBSException e) {
			statement.setMsg(e.getMessage());
			statement.setBool(false);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);
		}
		return entity;
	}

	@PostMapping("/sellSilver")
	public ResponseEntity<Statement> sellSilver(@RequestBody Units sUnits) {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
		try {
			customerService.sellSilver(sUnits.getUnits(), userId);
			statement.setMsg("You successfully sold your silver units");
			statement.setBool(true);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		} catch (IBSException e) {
			statement.setMsg(e.getMessage());
			statement.setBool(false);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);
		}
		return entity;
	}

	@PostMapping("/investSipMf")
	public ResponseEntity<Statement> investSip( @RequestBody SipData sipdata
			) {
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
		try {
			statement.setBool(true);
			statement.setMsg("You successfully invested in the Mutual fund");
			BankMutualFund bk= customerService.viewMFPlans().get(sipdata.getMfPlanId());
		MutualFund fund = sipdata.getMutualFund();
		fund.setBankMutualFund(bk);
			customerService.investSipMF(userId, fund);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		} catch (IBSException e) {
			statement.setMsg(e.getMessage());
			statement.setBool(false);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);
		}
		return entity;
	}

	@GetMapping("/viewSipMf")
	public ResponseEntity<List<BankMutualFund>> viewSIPMfPlans() {
		List<BankMutualFund> sipList = null;
		ResponseEntity<List<BankMutualFund>> entity = new ResponseEntity<List<BankMutualFund>>(HttpStatus.OK);
		try {
			HashMap<Integer, BankMutualFund> bkmap = customerService.viewMFPlans();
			List<BankMutualFund> bankList = new ArrayList<BankMutualFund>(bkmap.values());
			sipList = new ArrayList<BankMutualFund>();
			for (BankMutualFund bk : bankList) {
				if (bk.getSipStatus() == true) {
					sipList.add(bk);
				}
			}
			entity = new ResponseEntity<List<BankMutualFund>>(sipList, HttpStatus.OK);
		} catch (IBSException e) {
			entity = new ResponseEntity<List<BankMutualFund>>(HttpStatus.BAD_REQUEST);
		}
		return entity;
	}

	@GetMapping("/viewTrans")
	public ResponseEntity<List<TransactionView>> viewTrans() {
		List<InvestmentTransaction> transList = new ArrayList<InvestmentTransaction>();
		List<TransactionView> transList1 = new ArrayList<TransactionView>();
		ResponseEntity<List<TransactionView>> entity = new ResponseEntity<List<TransactionView>>(
				HttpStatus.BAD_REQUEST);
		try {
			
			transList = customerService.getTransactions(userId);
			for(InvestmentTransaction trnx:transList) {
				TransactionView temp = new TransactionView();
				temp.setTransactionId(trnx.getTransactionId());
				
				temp.setAccountNumber(trnx.getAccount().getAccNo());
				temp.setPricePerUnits(trnx.getPricePerUnit());
				temp.setTransactionAmount(trnx.getTransactionAmount());
				temp.setTransactionBalance(trnx.getTrxBalance());
				temp.setTransactionDate(trnx.getTransactionDate());
				temp.setTransactionDescription(trnx.getTransactionDescription());
				temp.setTransactionMode(trnx.getTransactionMode());
				temp.setTransactionType(trnx.getTransactionType());
				temp.setUnits(trnx.getUnits());
				transList1.add(temp);
				
			}
			entity = new ResponseEntity<List<TransactionView>>(transList1, HttpStatus.OK);
		} catch (IBSException e) {
			entity = new ResponseEntity<List<TransactionView>>(HttpStatus.BAD_REQUEST);
		}
		return entity;
	}

	@GetMapping("/viewDirectMf")
	public ResponseEntity<List<BankMutualFund>> viewDirMfplans() throws IBSException {
		List<BankMutualFund> dirList = null;
		ResponseEntity<List<BankMutualFund>> entity = new ResponseEntity<List<BankMutualFund>>(HttpStatus.OK);
		
			HashMap<Integer, BankMutualFund> bkmap = customerService.viewMFPlans();
			List<BankMutualFund> bankList = new ArrayList<BankMutualFund>(bkmap.values());
			dirList = new ArrayList<BankMutualFund>();
			for (BankMutualFund bk : bankList) {
				if (bk.getDirStatus() == true) {
					dirList.add(bk);
				}
			}
			System.out.println(dirList);
			entity = new ResponseEntity<List<BankMutualFund>>(dirList, HttpStatus.OK);
		
		return entity;
	}

	@PostMapping("/withdrawDirMf")
	public ResponseEntity<Statement> withdrawDirMf(@RequestBody WithdrawDir withdrawData ) throws IBSException {
		
		Statement statement = new Statement();
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		/*
		 * try { Set<MutualFund> mutual =
		 * customerService.viewInvestments(userId).getFunds(); Map<Integer, MutualFund>
		 * dirMap = new HashMap<Integer, MutualFund>(); for (MutualFund mutualFund :
		 * mutual) { if (mutualFund.getType().compareTo(MFType.DIRECT) == 0) {
		 * dirMap.put(mutualFund.getFolioNumber(), mutualFund); } } if
		 * (dirMap.containsKey(withdrawData.getFolioNumber())) {
		 */
				customerService.withdrawDirMF(userId,withdrawData);
				statement.setMsg("Direct Mutual Fund successfully withdrawn");
				statement.setBool(true);
				
				entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		/*
		 * } else { entity = new ResponseEntity<String>("No Mutual Fund found",
		 * HttpStatus.BAD_REQUEST); }
		 */

		/*
		 * } catch (Exception e) { entity = new ResponseEntity<String>(e.getMessage(),
		 * HttpStatus.BAD_REQUEST); }
		 */
		return entity;
	}

	@PostMapping("/withdrawSipMf")
	public ResponseEntity<Statement> withdrawSipMf(@RequestBody WithdrawDir withdrawData) {
		String message = null;
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		Statement statement = new Statement();
		Map<Integer, MutualFund> sipMap = new HashMap<Integer, MutualFund>();
		try {
			Set<MutualFund> mutual = customerService.viewInvestments(userId).getFunds();
			for (MutualFund mutualFund : mutual) {
				if (mutualFund.getType().compareTo(MFType.SIP) == 0) {
					sipMap.put(mutualFund.getFolioNumber(), mutualFund);
				}
			}
			if (sipMap.containsKey(withdrawData.getFolioNumber())) {
				customerService.withdrawSipMF(userId, sipMap.get(withdrawData.getFolioNumber()));
				statement.setMsg("SIP Mutual Fund successfully withdrawn");
				statement.setBool(true);
				
				
				entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
			} else {
				statement.setMsg("No such SIP exists");
				statement.setBool(false);
				entity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			statement.setMsg(e.getMessage());
			statement.setBool(false);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);
		}
		return entity;
	}

	@PostMapping("linkAccount")
	public ResponseEntity<Statement> linkAccount(@RequestBody Units units) {
		Statement statement = new Statement();
		ResponseEntity<Statement> entity = new ResponseEntity<Statement>(HttpStatus.BAD_REQUEST);
		try {statement.setMsg("Account Linked successfully");
		statement.setBool(true);
			
			customerService.linkMyAccount(units.getAccNo(), userId);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.OK);
		} catch (IBSException e) {
			statement.setMsg(e.getMessage());
			statement.setBool(false);
			entity = new ResponseEntity<Statement>(statement, HttpStatus.BAD_REQUEST);
		}
		return entity;
	}

}
