package com.cg.ibs.investment.model;

import java.math.BigInteger;

public class Units {
	private Double units;
	private BigInteger accNo;
	private String userId;
	
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public BigInteger getAccNo() {
		return accNo;
	}

	public void setAccNo(BigInteger accNo) {
		this.accNo = accNo;
	}

	public Double getUnits() {
		return units;
	}

	public void setUnits(Double units) {
		this.units = units;
	}
	

}
