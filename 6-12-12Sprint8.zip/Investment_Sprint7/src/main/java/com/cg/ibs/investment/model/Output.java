package com.cg.ibs.investment.model;

public class Output {
private String msg;
private Boolean bool;
private Integer mfPlanId;
private double amt;

public double getAmt() {
	return amt;
}
public void setAmt(double amt) {
	this.amt = amt;
}
public Integer getMfPlanId() {
	return mfPlanId;
}
public void setMfPlanId(Integer mfPlanId) {
	this.mfPlanId = mfPlanId;
}
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}
public Boolean getBool() {
	return bool;
}
public void setBool(Boolean bool) {
	this.bool = bool;
}



}
