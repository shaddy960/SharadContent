package com.cg.ibs.investment.dao;

import java.util.List;

import com.cg.ibs.investment.bean.AccountHolding;


public interface AccHoldDao {
	AccountHolding addAccountHold(AccountHolding accHold);

	AccountHolding updateAccountHold(AccountHolding accHold);

	AccountHolding getAccountByAccNo(Long aHId);

	List<AccountHolding> getAllAccounts();

	boolean removeAccountHold(Long aHId);
}
