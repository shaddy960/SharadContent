package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.cg.ibs.investment.bean.Account;

import com.cg.ibs.investment.bean.GoldPrice;
@Repository("accDao")
public class AccountDaoImpl implements AccountDao {
	@PersistenceContext
	private EntityManager entityManager;

	

	public Account addAccount(Account account) {
		entityManager.persist(account);
		return account;
	}

	public Account updateAccount(Account account) {
		return entityManager.merge(account);
	}

	public Account getAccountByAccNo(BigInteger accNo) {
		return entityManager.find(Account.class, accNo);
	}

	public List<Account> getAllAccounts() {
		CriteriaQuery<Account> query = entityManager.getCriteriaBuilder().createQuery(Account.class);
		Root<Account> root = query.from(Account.class);
		query.select(root);

		return entityManager.createQuery(query).getResultList();
	}

	public boolean removeAccount(BigInteger accNo) {
		boolean isDeleted = false;
		Account bean = getAccountByAccNo(accNo);
		if (null != bean) {
			entityManager.remove(bean);
			isDeleted = true;
		}
		return isDeleted;
	}
	public List<Account> getAccByUci(BigInteger uci) {
		TypedQuery<Account> query = (TypedQuery<Account>) entityManager.createNamedQuery("getAccByUci",Account.class);
	   query.setParameter(1, uci);
	   List<Account> list=query.getResultList();
		return list;
	}
	

}
