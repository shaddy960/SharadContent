package com.cg.ibs.investment.ui;

public enum ViewMFPlans {
	SIP,DIRECT,SIP_AND_DIRECT,GO_BACK

}
