package com.cg.ibs.investment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.CustomerService;

@Controller
public class CustomerController {
	
	@Autowired
	private CustomerService service;
	
	@RequestMapping("/customer")
	public ModelAndView showDeptsHome(){
		return new ModelAndView("customerLogin");
	}
	
	
	@RequestMapping("/custLogin")
	public ModelAndView customerLogin(@RequestParam("userId")String userId, @RequestParam("password")String password) {
		ModelAndView modelAndView = new ModelAndView();
			if(service.validateCustomer(userId, password)) {
				
				modelAndView = new ModelAndView("customerMenu");
			}
		
	
	return modelAndView;
	}

}
