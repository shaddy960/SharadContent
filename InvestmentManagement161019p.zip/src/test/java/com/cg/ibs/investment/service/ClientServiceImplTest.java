package com.cg.ibs.investment.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.dao.ClientDao;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.exception.IBSException;

class ClientServiceImplTest {

	ClientService clientService;
	InvestmentBean investmentBean;
	ClientDao clientdao;

	@BeforeEach
	void doit() {
		clientService = new ClientServiceImpl();
		clientdao = new InvestmentDaoImpl();
		investmentBean = clientdao.viewInvestments("a");
	}

	@Test
	@DisplayName("Checking Sufficient Balance")
	void testBuyGold1() {
		// assertThrows(IBSException.class, () ->clientdao.viewInvestments("a").getBalance());

		assertTrue(() -> clientdao.viewInvestments("a").getBalance() >= 10*clientdao.viewGoldPrice());
		
	}

	@Test
	@DisplayName("Insuff Balance Exception Message")
	void testBuyGold2() {
		assertThrows(IBSException.class, () -> clientService.buyGold(100, "a"));
			
	}

}
