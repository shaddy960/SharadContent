package com.cg.ibs.investment.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.ibs.common.bean.TransactionBean;
import com.cg.ibs.common.bean.TransactionType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;

public class InvestmentStore {

	private double goldPrice;
	private double silverPrice;
	private LocalDate date;
	private HashMap<String, BankMutualFund> mutualFunds = new HashMap<>();
	private HashMap<String, MutualFund> mutualFundscust1 = new HashMap<>();
	private HashMap<String, MutualFund> mutualFundscust2 = new HashMap<>();
	private HashMap<String, InvestmentBean> investmentBeans = new HashMap<>();
	private HashMap<String, String> userIDMap = new HashMap<>();
	public List<TransactionBean> transactionBeans = new ArrayList<TransactionBean>();
	private static InvestmentStore investmentStore = new InvestmentStore();

	private InvestmentStore() {
		super();

	}

	public double getGoldPrice() {
		return goldPrice;
	}

	public void setGoldPrice(double goldPrice) {
		this.goldPrice = goldPrice;
	}

	public double getSilverPrice() {
		return silverPrice;
	}

	public void setSilverPrice(double silverPrice) {
		this.silverPrice = silverPrice;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public HashMap<String, BankMutualFund> getMutualFunds() {
		return mutualFunds;
	}

	public void setMutualFunds(HashMap<String, BankMutualFund> mutualFunds) {
		this.mutualFunds = mutualFunds;
	}

	public HashMap<String, MutualFund> getMutualFundscust1() {
		return mutualFundscust1;
	}

	public void setMutualFundscust1(HashMap<String, MutualFund> mutualFundscust1) {
		this.mutualFundscust1 = mutualFundscust1;
	}

	public HashMap<String, MutualFund> getMutualFundscust2() {
		return mutualFundscust2;
	}

	public void setMutualFundscust2(HashMap<String, MutualFund> mutualFundscust2) {
		this.mutualFundscust2 = mutualFundscust2;
	}

	public HashMap<String, InvestmentBean> getInvestmentBeans() {
		return investmentBeans;
	}

	public void setInvestmentBeans(HashMap<String, InvestmentBean> investmentBeans) {
		this.investmentBeans = investmentBeans;
	}

	public HashMap<String, String> getUserIDMap() {
		return userIDMap;
	}

	public void setUserIDMap(HashMap<String, String> userIDMap) {
		this.userIDMap = userIDMap;
	}

	public List<TransactionBean> getTransactionBeans() {
		return transactionBeans;
	}

	public void setTransactionBeans(List<TransactionBean> transactionBeans) {
		this.transactionBeans = transactionBeans;
	}

	public static InvestmentStore getInvestmentStore() {
		return investmentStore;
	}

	public static void setInvestmentStore(InvestmentStore investmentStore) {
		InvestmentStore.investmentStore = investmentStore;
	}

	private InvestmentStore(double goldPrice, double silverPrice, LocalDate date,
			HashMap<String, BankMutualFund> mutualFunds, HashMap<String, MutualFund> mutualFundscust1,
			HashMap<String, MutualFund> mutualFundscust2, HashMap<String, InvestmentBean> investmentBeans,
			HashMap<String, String> userIDMap, List<TransactionBean> transactionBeans) {
		super();
		this.goldPrice = goldPrice;
		this.silverPrice = silverPrice;
		this.date = date;
		this.mutualFunds = mutualFunds;
		this.mutualFundscust1 = mutualFundscust1;
		this.mutualFundscust2 = mutualFundscust2;
		this.investmentBeans = investmentBeans;
		this.userIDMap = userIDMap;
		this.transactionBeans = transactionBeans;
	}

	public static InvestmentStore getInstance() {
		if (investmentStore == null) {
			investmentStore = new InvestmentStore();
		}
		return investmentStore;
	}

	static {
		if (investmentStore == null) {
			investmentStore = new InvestmentStore();
		}

		BankMutualFund hdfc = new BankMutualFund("HDFC", 250);
		BankMutualFund sbi = new BankMutualFund("SBI", 300);
		BankMutualFund icici = new BankMutualFund("ICICI", 200);
		investmentStore.mutualFunds.put("HDFC", hdfc);
		investmentStore.mutualFunds.put("SBI", sbi);
		investmentStore.mutualFunds.put("ICICI", icici);
		investmentStore.mutualFundscust1.put("HDFC", new MutualFund("HDFC", 250, 150, null, LocalDate.now(), null, false));
		investmentStore.mutualFundscust2.put("ICICI", new MutualFund("ICICI", 250, 100, null, LocalDate.now(), null, false));
		LocalDate date;

		TransactionBean trxn1 = new TransactionBean(new BigInteger("100100100"), TransactionType.CREDIT,
				LocalDate.now(), new BigDecimal("2000"));
		TransactionBean trxn2 = new TransactionBean(new BigInteger("100100100"), TransactionType.DEBIT, LocalDate.now(),
				new BigDecimal("2000"));
		investmentStore.transactionBeans.add(trxn1);
		investmentStore.transactionBeans.add(trxn2);

		InvestmentBean cust1 = new InvestmentBean("4100101", "Sachin", "mumbai", 220.0, 2000.0, 50000.0,
				investmentStore.mutualFundscust1, investmentStore.transactionBeans);
		InvestmentBean cust2 = new InvestmentBean("4100102", "Gautam", "delhi", 300.0, 3000.0, 40000.0,
				investmentStore.mutualFundscust2, investmentStore.transactionBeans);
		investmentStore.investmentBeans.put("Sachin", cust1);
		investmentStore.investmentBeans.put("Gautam", cust2);

		investmentStore.goldPrice = 35000;
		investmentStore.silverPrice = 29000;

	}

}
