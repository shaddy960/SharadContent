package com.cg.ibs.investment.exception;

public interface IBSException{
	
		

}
