package com.cg.ibs.investment.bean;

import java.math.BigDecimal;
import java.time.LocalDate;

public class MutualFund {
	private String id;
	private double nav;
	private double mfunits;
	private BigDecimal premiumBal;
	private LocalDate openingDate;
	private LocalDate closingDate=null;
	private boolean status=false;
	
	public MutualFund(){
		
	}

	public MutualFund(String id, double nav, double mfunits, BigDecimal premiumBal, LocalDate openingDate,
			LocalDate closingDate, boolean status) {
		super();
		this.id = id;
		this.nav = nav;
		this.mfunits = mfunits;
		this.premiumBal = BigDecimal.valueOf(nav*mfunits);
		this.openingDate = openingDate;
		this.closingDate = closingDate;
		this.status = status;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getNav() {
		return nav;
	}

	public void setNav(double nav) {
		this.nav = nav;
	}

	public double getMfunits() {
		return mfunits;
	}

	public void setMfunits(double mfunits) {
		this.mfunits = mfunits;
	}

	public BigDecimal getPremiumBal() {
		return premiumBal;
	}

	public void setPremiumBal(BigDecimal premiumBal) {
		this.premiumBal = premiumBal;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public LocalDate getClosingDate() {
		return closingDate;
	}

	public void setClosingDate(LocalDate closingDate) {
		this.closingDate = closingDate;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "MutualFund [id=" + id + ", nav=" + nav + ", mfunits=" + mfunits + ", premiumBal=" + premiumBal
				+ ", openingDate=" + openingDate + ", closingDate=" + closingDate + ", status=" + status + "]";
	}
	
	
}
