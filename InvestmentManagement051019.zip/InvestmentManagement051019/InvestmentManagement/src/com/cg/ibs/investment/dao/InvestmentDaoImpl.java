
	package com.cg.ibs.investment.dao;
	import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
	import java.util.HashMap;
	import java.util.HashSet;
	import java.util.List;
	import java.util.Map;
	import java.util.Set;
	import java.math.BigDecimal;
	import java.math.BigInteger;
	import java.time.LocalDate;

	import com.cg.ibs.common.bean.TransactionBean;
	import com.cg.ibs.common.bean.TransactionType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
	import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.InvalidDetailsException;
import com.cg.ibs.investment.exception.InvalidGoldPriceException;
import com.cg.ibs.investment.exception.InvalidSilverPriceException;

	public class InvestmentDaoImpl implements BankDao, ClientDao  {
		
		private InvestmentStore store;
		
		public InvestmentDaoImpl() {
			store = InvestmentStore.getInstance();
		}
		

		@Override
		public double viewGoldPrice() {
			return store.getGoldPrice();
		}

		@Override
		public double viewSilverPrice() {
			
			return store.getSilverPrice();
		}

		@Override
		public InvestmentBean viewInvestments(String uCI)throws InvalidDetailsException {
			
			return store.getInvestmentBeans().get(uCI);
		}

		@Override
		public HashMap<String, BankMutualFund> viewMF() {
			
			return store.getMutualFunds() ;
		}

		@Override
		public void updateTransaction(String uCI, TransactionBean trxn) {
			store.getInvestmentBeans().get(uCI).getTransactionList().add(trxn);
			
		}

		@Override
		public void updateGoldPrice(double x) throws InvalidGoldPriceException {
			this.store.setGoldPrice(x);
			
		}

		@Override
		public void updateSilverPrice(double y) throws InvalidSilverPriceException {
			this.store.setSilverPrice(y);
			
		}

		@Override
		public void updateMF(BankMutualFund mutualFund) {
			store.getMutualFunds().put(mutualFund.getId(), mutualFund);
			
		}

		@Override
		public boolean validateCustomer(String userId, String password) {
			
			return false;
		}


		@Override
		public void updateMF(MutualFund mutualFund) {
			// TODO Auto-generated method stub
			
		}
		

}
