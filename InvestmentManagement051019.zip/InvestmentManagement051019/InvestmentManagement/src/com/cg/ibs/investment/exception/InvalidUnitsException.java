package com.cg.ibs.investment.exception;

public class InvalidUnitsException extends Exception implements IBSException {

	private static final long serialVersionUID = 1L;

	public InvalidUnitsException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidUnitsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidUnitsException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidUnitsException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InvalidUnitsException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
