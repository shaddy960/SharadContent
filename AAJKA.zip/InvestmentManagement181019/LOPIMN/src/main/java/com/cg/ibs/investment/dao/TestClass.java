package com.cg.ibs.investment.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import com.cg.ibs.common.bean.AccountBean;
import com.cg.ibs.common.bean.CustomerBean;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.IBSException;

public class TestClass {

	public static void main(String[] args) throws IBSException {

		InvestmentBean investmentBean= new InvestmentBean();
		Set<MutualFund> mFunds=new HashSet<>();
		
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_MY_INVESTMENTS);
						PreparedStatement pst1=con.prepareStatement(QueryMapper.VIEW_MY_MF);) {
			pst.setString(1, "5555111151513301");
			ResultSet rs = pst.executeQuery();
			ResultSet rs1=pst1.executeQuery();
			if (rs.next()) {
				investmentBean.setBalance(rs.getDouble("current_balance"));
				investmentBean.setUCI(rs.getString("uci"));
				investmentBean.setGoldunits(rs.getDouble("gold_units"));
				investmentBean.setSilverunits(rs.getDouble("silver_units"));
				investmentBean.setAccount_Number(rs.getString("account_number"));
				
			}
			while(rs1.next()) {
				MutualFund mfc=new MutualFund();
				mfc.setmfid(rs1.getInt("mf_id"));
				mfc.setMfUnits(rs1.getDouble("mf_units"));
				mfc.setMfAmount(rs1.getDouble("mf_amount"));
				mfc.setOpeningDate(rs1.getDate("opening_date").toLocalDate());
				if(rs1.getDate("closing_date")!=null) {
					mfc.setClosingDate(rs1.getDate("closing_date").toLocalDate());
				}
				else {
					mfc.setClosingDate(null);
				}
				mFunds.add(mfc);
			}
			investmentBean.setFunds(mFunds);
		}
		catch (SQLException | IOException e) {
			throw new IBSException(e.getMessage());
		}
			 
		
		System.out.println(investmentBean);

}
}