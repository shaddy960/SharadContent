package com.cg.ibs.common.bean;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Set;

public class AccountBean {
	private BigInteger accountNumber;
	private Set<CustomerBean> accountHolders;
	private BigDecimal currentBalance;
	private String transactionPassword;
	private List<TransactionBean> transactions;
	private BigInteger uci;

	public AccountBean() {
		super();
	}

	public AccountBean(BigInteger accountNumber, Set<CustomerBean> accountHolders, BigDecimal currentBalance,
			String transactionPassword, List<TransactionBean> transactions, BigInteger uci) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolders = accountHolders;
		this.currentBalance = currentBalance;
		this.transactionPassword = transactionPassword;
		this.transactions = transactions;
		this.uci = uci;
	}

	public BigInteger getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(BigInteger accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Set<CustomerBean> getAccountHolders() {
		return accountHolders;
	}

	public void setAccountHolders(Set<CustomerBean> accountHolders) {
		this.accountHolders = accountHolders;
	}

	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getTransactionPassword() {
		return transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public List<TransactionBean> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<TransactionBean> transactions) {
		this.transactions = transactions;
	}

	public BigInteger getUci() {
		return uci;
	}

	public void setUci(BigInteger uci) {
		this.uci = uci;
	}

	@Override
	public String toString() {
		return "AccountBean [accountNumber=" + accountNumber + ", currentBalance=" + currentBalance + ", uci=" + uci
				+ "]";
	}

	public AccountBean(BigInteger accountNumber, BigDecimal currentBalance, BigInteger uci) {
		super();
		this.accountNumber = accountNumber;
		this.currentBalance = currentBalance;
		this.uci = uci;
	}

	

}
