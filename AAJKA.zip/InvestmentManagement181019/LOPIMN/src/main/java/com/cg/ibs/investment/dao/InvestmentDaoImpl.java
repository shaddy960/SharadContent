package com.cg.ibs.investment.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.cg.ibs.common.bean.AccountBean;
import com.cg.ibs.common.bean.CustomerBean;
import com.cg.ibs.common.bean.TransactionBean;
import com.cg.ibs.common.bean.TransactionType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.IBSException;

public class InvestmentDaoImpl implements BankDao, ClientDao {

	//Declaring data members
	private static double goldPrice;			
	private static double silverPrice;
	private static HashMap<Integer, BankMutualFund> mutualFunds = new HashMap<>();
	private static Set<MutualFund> mutualFundscust1;
	private static Set<MutualFund> mutualFundscust2;
	private static Set<MutualFund> mutualFundscust3;
	private static Set<MutualFund> mutualFundscust4;
	private static Set<MutualFund> mutualFundscust5;
	private static HashMap<String, InvestmentBean> investmentBeans = new HashMap<>();
	private static TreeSet<TransactionBean> transactionBeancust1;
	private static TreeSet<TransactionBean> transactionBeancust2;
	private static TreeSet<TransactionBean> transactionBeancust3;
	private static TreeSet<TransactionBean> transactionBeancust4;
	private static TreeSet<TransactionBean> transactionBeancust5;
	static long count;

	
	static Logger log = Logger.getLogger(InvestmentDaoImpl.class.getName());
	//Method to view Gold Price
	@Override
	public double viewGoldPrice() throws IBSException  {
		double gold_price = 0;
		try (
			Connection con = ConnectionProvider.getInstance().getConnection();
			PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_GOLD_PRICE);){
			pst.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
			ResultSet resultSet = pst.executeQuery();

			if (resultSet.next()) {

				gold_price = resultSet.getDouble(2);
			}
			pst.close();
		} catch (SQLException | IOException e) {
			System.out.println(e.getMessage());
		}
		return gold_price;
	}

	
	//Method to view Silver Price
	@Override
	public double viewSilverPrice() {
		double silver_price = 0;
		try (
			Connection con = ConnectionProvider.getInstance().getConnection();
			PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_SILVER_PRICE);){
			System.out.println(LocalDate.now());
			pst.setDate(1, java.sql.Date.valueOf(LocalDate.now()));

			ResultSet resultSet = pst.executeQuery();
			if (resultSet.next()) {

				silver_price = resultSet.getDouble(2);
			}
			pst.close();
		} catch (SQLException | IOException e) {
			System.out.println(e.getMessage());
		}

		return silver_price;
	}

	//Method to view Investments of the Customer
	@Override
	public InvestmentBean viewInvestments(String uci) throws IBSException {
		InvestmentBean investmentBean= new InvestmentBean();
		Set<MutualFund> mFunds=new HashSet<>();
		
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_MY_INVESTMENTS);
						PreparedStatement pst1=con.prepareStatement(QueryMapper.VIEW_MY_MF);) {
			pst.setString(1, uci);
			pst1.setString(1, uci);
			ResultSet rs = pst.executeQuery();
			ResultSet rs1=pst1.executeQuery();
			if (rs.next()) {
				investmentBean.setBalance(rs.getDouble("current_balance"));
				investmentBean.setUCI(rs.getString("uci"));
				investmentBean.setGoldunits(rs.getDouble("gold_units"));
				investmentBean.setSilverunits(rs.getDouble("silver_units"));
				investmentBean.setAccount_Number(rs.getString("account_number"));
				
			}
			while(rs1.next()) {
				MutualFund mfc=new MutualFund();
				mfc.setmfid(rs1.getInt("mf_id"));
				mfc.setMfUnits(rs1.getDouble("mf_units"));
				mfc.setMfAmount(rs1.getDouble("mf_amount"));
				mfc.setTitle(rs1.getString("mf_title"));
				mfc.setNav(rs1.getDouble("nav"));
				mfc.setOpeningDate(rs1.getDate("opening_date").toLocalDate());
				if(rs1.getDate("closing_date")!=null) {
					mfc.setClosingDate(rs1.getDate("closing_date").toLocalDate());
				}
				else {
					mfc.setClosingDate(null);
				}
				mFunds.add(mfc);
			}
			investmentBean.setFunds(mFunds);
		}
		catch (SQLException | IOException e) {
			throw new IBSException(e.getMessage());
		}
			 
		
		return investmentBean;
	}

	//Method to view Mutual Fund plans provided by the bank
	@Override
	public HashMap<Integer, BankMutualFund> viewMF() throws IBSException {
		
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_BANK_MF)) {
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				BankMutualFund bk=new BankMutualFund(rs.getInt("mf_plan_id"), rs.getString("mf_title"), rs.getDouble("nav"));
				mutualFunds.put(rs.getInt("mf_plan_id"), bk);
			}
		}
		catch (SQLException | IOException e) {
			throw new IBSException(e.getMessage());
		}
		return mutualFunds;
	}

	////Method to update transactions of the customer
	@Override
	public void updateTransaction(String uCI, int choice, InvestmentBean investmentBean, double amount) {
		if (choice == 1) {

			BigInteger TransactionId = new BigInteger("1001001000031").add(BigInteger.valueOf(count));
			TransactionBean trxn1 = new TransactionBean(TransactionId, TransactionType.DEBIT, LocalDate.now(),
					BigDecimal.valueOf(amount));
			investmentBean.getTransactionList().add(trxn1);
			investmentBean.setTransactionList(investmentBean.getTransactionList());
			count++;
		} else if (choice == 2) {

			BigInteger TransactionId = new BigInteger("10010010000311").add(BigInteger.valueOf(count));
			TransactionBean trxn1 = new TransactionBean(TransactionId, TransactionType.CREDIT, LocalDate.now(),
					BigDecimal.valueOf(amount));
			investmentBean.getTransactionList().add(trxn1);
			investmentBean.setTransactionList(investmentBean.getTransactionList());
			count++;
		}else if (choice == 3) {
			BigInteger TransactionId = new BigInteger("10010010000311").add(BigInteger.valueOf(count));
			TransactionBean trxn1 = new TransactionBean(TransactionId, TransactionType.GOLD_CREDIT, LocalDate.now(),
					BigDecimal.valueOf(amount),goldPrice);
			investmentBean.getTransactionList().add(trxn1);
			investmentBean.setTransactionList(investmentBean.getTransactionList());
			count++;
			
		}else if (choice == 4) {
			BigInteger TransactionId = new BigInteger("10010010000311").add(BigInteger.valueOf(count));
			TransactionBean trxn1 = new TransactionBean(TransactionId, TransactionType.GOLD_DEBIT, LocalDate.now(),
					BigDecimal.valueOf(amount),goldPrice);
			investmentBean.getTransactionList().add(trxn1);
			investmentBean.setTransactionList(investmentBean.getTransactionList());
			count++;
			
		}else if (choice == 5) {
			BigInteger TransactionId = new BigInteger("10010010000311").add(BigInteger.valueOf(count));
			TransactionBean trxn1 = new TransactionBean(TransactionId, TransactionType.SILVER_CREDIT, LocalDate.now(),
					BigDecimal.valueOf(amount),silverPrice);
			investmentBean.getTransactionList().add(trxn1);
			investmentBean.setTransactionList(investmentBean.getTransactionList());
			count++;
			
		}else if (choice == 6) {
			BigInteger TransactionId = new BigInteger("10010010000311").add(BigInteger.valueOf(count));
			TransactionBean trxn1 = new TransactionBean(TransactionId, TransactionType.SILVER_DEBIT, LocalDate.now(),
					BigDecimal.valueOf(amount),silverPrice);
			investmentBean.getTransactionList().add(trxn1);
			investmentBean.setTransactionList(investmentBean.getTransactionList());
			count++;
			
		}


	}

	//Method to update Gold Price
	@Override
	public boolean updateGoldPrice(double x) {
		boolean status = false;
		try (
			Connection con = ConnectionProvider.getInstance().getConnection();
			PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_GOLD_PRICE);){
			pst.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				status = false;
			} else {
				PreparedStatement pst1 = con.prepareStatement(QueryMapper.UPDATE_GOLD_PRICE);
				pst1.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
				pst1.setDouble(2, goldPrice);
				pst1.execute();
				status = true;
			}

		} catch (SQLException | IOException e) {
		}
		return status;
		
		
	}

	//Method to update Silver Price
	@Override
	public boolean updateSilverPrice(double y) {
		boolean status = false;
		try (
			Connection con = ConnectionProvider.getInstance().getConnection();
			PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_SILVER_PRICE);){
			pst.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				status = false;
			} else {
				PreparedStatement pst1 = con.prepareStatement(QueryMapper.UPDATE_SILVER_PRICE);
				pst1.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
				pst1.setDouble(2, y);
				pst1.execute();
				status = true;
			}

		} catch (SQLException | IOException e) {
		}
		return status;

	}

	//Method to add new Mutual Fund plans
	@Override
	public boolean addMF(BankMutualFund mutualFund) {
		boolean status = false;
		if(!mutualFunds.containsKey(mutualFund.getmfid())){
		mutualFunds.put(mutualFund.getmfid(), mutualFund);
		status=true;
		}
      return status;
	}

	//Method to view details of Bank representative
	@Override
	public InvestmentBean viewDetails(String userId) {
		return investmentBeans.get(userId);
	}

	//Method to update Gold and Silver units of the customer
	@Override
	public void updateUnits(String uci, double units, InvestmentBean investmentBean, int choice) throws IBSException {
		InvestmentBean temp=viewInvestments(uci);
		if (choice == 1) {
			try (
				Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.GOLD_UNITS);
				PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.BALANCE);){
				System.out.println(LocalDate.now());
				pst.setString(2,uci);
				pst.setDouble(1,temp.getGoldunits() + units);
				pst.execute();
				preparedStatement.setString(2,uci);
				preparedStatement.setDouble(1,temp.getBalance() - units * viewGoldPrice());
				preparedStatement.execute();
			} catch (SQLException | IOException e) {
				e.printStackTrace();
			}

		} else if (choice == 2) {
			try (
				Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.GOLD_UNITS);
					PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.BALANCE);){
				System.out.println(LocalDate.now());
				pst.setString(2,uci);
				pst.setDouble(1, temp.getGoldunits() - units);
				pst.execute();
				
				preparedStatement.setString(2, uci);
				preparedStatement.setDouble(1, temp.getBalance() + units * viewGoldPrice());
				preparedStatement.execute();
			} catch (SQLException | IOException e) {
				e.printStackTrace();
			}
		} else if (choice == 3) {
			try (
				Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.SILVER_UNITS);
					PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.BALANCE);){
				System.out.println(LocalDate.now());
				pst.setString(2,uci);
				pst.setDouble(1, temp.getGoldunits() + units);
				pst.execute();
				
				preparedStatement.setString(2, uci);
				preparedStatement.setDouble(1, temp.getBalance() - units * viewGoldPrice());
				preparedStatement.execute();
			} catch (SQLException | IOException e) {
				e.printStackTrace();
			}
		} else if (choice == 4) {
			try (
				Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.SILVER_UNITS);
					PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.BALANCE);){
				System.out.println(LocalDate.now());
				pst.setString(2,uci);
				pst.setDouble(1, temp.getGoldunits() - units);
				pst.execute();
				
				preparedStatement.setString(2, uci);
				preparedStatement.setDouble(1, temp.getBalance() + units * viewGoldPrice());
				preparedStatement.execute();
			} catch (SQLException | IOException e) {
				System.out.println(e.getMessage());
			}
			
		}

	}

	//Method to invest in Mutual funds for a customer
	@Override
	public void addMFInvestments(double mfAmount, int mfId, InvestmentBean investmentBean) {

		double nav = mutualFunds.get(mfId).getNav();
		MutualFund mutualFund = new MutualFund();
		mutualFund.setmfid(mfId);
		mutualFund.setTitle(mutualFunds.get(mfId).getTitle());
		mutualFund.setNav(mutualFunds.get(mfId).getNav());
		LocalDate dt = LocalDate.now();
		double mfunits = (mfAmount / nav);
		mutualFund.setMfUnits(mfunits);
		mutualFund.setOpeningDate(dt);
		mutualFund.setStatus(true);

		investmentBean.getFunds().add(mutualFund);
		investmentBean.setFunds(investmentBean.getFunds());
		investmentBean.setBalance(investmentBean.getBalance() - mfAmount);

	}

	//Method to withdraw Mutual fund of a customer
	@Override
	public void withdrawMF(String userId, MutualFund mutualFund, InvestmentBean investmentBean) {
		investmentBean.setBalance(investmentBean.getBalance() + mutualFund.getMfAmount());

		investmentBean.getFunds().remove(mutualFund);

	}

	//Method to save Transactions history of a customer
	@Override
	public TreeSet<TransactionBean> getTransactions(String userId) {
		return investmentBeans.get(userId).getTransactionList();

	}
	
	public String getUcibyUseriD(String userId) throws IBSException {
		String uci=null;
		try (
			  Connection con=ConnectionProvider.getInstance().getConnection();
			PreparedStatement pst = con.prepareStatement(QueryMapper.GET_UCI);){
			pst.setString(1, userId);
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				uci=rs.getString("uci");
				
			}
		} catch (SQLException | IOException e) {
			throw  new IBSException(e.getMessage());
		
		}
		
		
		return uci;
		
	}
	@Override
	public CustomerBean getCustomer(String userid) {
		CustomerBean cs=new CustomerBean();
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.GET_CUSTOMER)) {
			pst.setString(1, userid);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				cs.setUserId(rs.getString("user_id"));
				cs.setPassword(rs.getString("password"));
				cs.setUCI(rs.getString("uci"));
				
			}
		}
		catch (SQLException | IOException e) {
			System.out.println(e.getMessage());;
		}
		return cs;
	}
	
	public ArrayList<AccountBean> getAccountsByUci(String uci) throws IBSException{
		
		ArrayList<AccountBean> acc=new ArrayList<>();
		
		try (
			Connection con=ConnectionProvider.getInstance().getConnection();
			PreparedStatement pst = con.prepareStatement(QueryMapper.GET_ACCOUNT_BY_UCI);){
			pst.setString(1, uci);
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				BigInteger uciNum=new BigInteger(rs.getString("uci"));				
				BigInteger accNum=new BigInteger(rs.getString("uci"));
				BigDecimal bal=new BigDecimal(rs.getDouble("current_balance"));
				AccountBean acb=new AccountBean(accNum, bal, uciNum);
				acc.add(acb);
				
			}
		} catch (SQLException | IOException e) {
			throw  new IBSException(e.getMessage());
		
		}
		return acc;
	}
	@Override
	public CustomerBean getBankAdmin(String userid) {
		CustomerBean cs=new CustomerBean();
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.GET_BANK_ADMIN)) {
			pst.setString(1, userid);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				cs.setUserId(rs.getString("admin_id"));
				cs.setPassword(rs.getString("password"));				
				
			}
		}
		catch (SQLException | IOException e) {
			System.out.println(e.getMessage());;
		}
		return cs;
	}
	
	

}
