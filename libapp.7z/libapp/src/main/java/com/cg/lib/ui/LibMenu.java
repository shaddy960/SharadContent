package com.cg.lib.ui;

public enum LibMenu {
	ADD,UPDATE,DELETE, QUIT,LIST
}
