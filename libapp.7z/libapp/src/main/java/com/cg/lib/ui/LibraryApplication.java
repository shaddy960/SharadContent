package com.cg.lib.ui;

import java.util.Scanner;

import com.cg.lib.model.Book;
import com.cg.lib.service.BookService;
import com.cg.lib.service.BookServiceImpl;
import com.cg.lib.ui.*;

public class LibraryApplication {
	public static Scanner scanner;
	public BookService bookService = new BookServiceImpl();
	public Book tempBook = new Book();

	public void init() {
		LibMenu choice = null;
		while (choice != LibMenu.QUIT) {
			System.out.println("Menu");
			System.out.println("--------------------");
			System.out.println("Choice");
			System.out.println("--------------------");
			for (LibMenu menu : LibMenu.values()) {
				System.out.println(menu.ordinal() + "\t" + menu);
			}
			System.out.println("Choice");
			int ordinal = scanner.nextInt();
			if (ordinal >= 0 && ordinal < LibMenu.values().length) {
				choice = LibMenu.values()[ordinal];

				switch (choice) {
				case ADD:
					doAdd();
					break;
				case UPDATE:
					doUpdate();
					break;
				case DELETE:
					doDelete();
					break;
				case LIST:
					doList();
					break;
				case QUIT:
					System.out.println("App Closed.");
					break;
				}
			} else {
				System.out.println("Invalid Option!!");
				choice = null;

			}

		}
	}

	public void doAdd() {
		

	}

	public void doUpdate() {
		// TODO Auto-generated method stub

	}

	public void doDelete() {
		// TODO Auto-generated method stub

	}

	public void doList() {
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) {
		scanner = new Scanner(System.in);
		LibraryApplication libapp = new LibraryApplication();
		libapp.init();
		scanner.close();

	}
}
