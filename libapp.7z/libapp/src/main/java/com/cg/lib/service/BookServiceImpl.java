package com.cg.lib.service;

import java.util.List;

import com.cg.lib.dao.BookDao;
import com.cg.lib.dao.BookDaoImpl;
import com.cg.lib.exception.LibException;
import com.cg.lib.model.Book;

public class BookServiceImpl implements BookService {
	private BookDao bookDao;
	
	public BookServiceImpl() {
		super();
		bookDao=new BookDaoImpl();
	}
	
	public boolean isValidBook(Book book){
		
		return true;
		
	}

	@Override
	public void addBook(Book book) throws LibException {
		if(isValidBook(book)){
			bookDao.addBook(book);
		}
		else throw new LibException("Book is not valid");
		
	}

	@Override
	public void updateBook(Book book) throws LibException {
		if(isValidBook(book)){
			bookDao.updateBook(book);
		}
		else throw new LibException("Book is not valid");
		
	}

	@Override
	public void deleteBook(int bookCode) throws LibException {
		bookDao.deleteBook(bookCode);
		
	}

	@Override
	public List<Book> getAllBooks(){
		
		try {
			return bookDao.getAllBooks();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Book getBookByID(int bookCode) throws LibException {
		
		return bookDao.getBookByID(bookCode);
	}

	@Override
	public List<Book> getAllBooksOrderedByBookCode() {
		
		return null;
	}

	@Override
	public List<Book> getAllBooksOrderedByTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> getAllBooksOrderedByPrice() {
		// TODO Auto-generated method stub
		return null;
	}

}
