import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';
import { ViewInvestment } from '../model/viewInvestment';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  baseUrl: string;
  viewInvUrl:string;
  result: Observable<String>;
  constructor(private http: HttpClient) { 
    this.baseUrl =`${environment.baseMwUrl}/customer/login`;
    this.viewInvUrl =`${environment.baseMwUrl}/customer/viewMyInvestment`;
  }

  custLogin(user:User): Observable<String> {
    console.log("jwebrfvl");
    console.log(user.userId);
    console.log(user.password);
    console.log("jhsdbc");
    this.result= this.http.post<String>(this.baseUrl,user);
    console.log(this.result);
    return this.result;
  }
  getInv():Observable<ViewInvestment>{
    return this.http.get<ViewInvestment>(this.viewInvUrl);
  }
}
