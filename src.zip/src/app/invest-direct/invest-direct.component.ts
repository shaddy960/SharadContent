import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invest-direct',
  templateUrl: './invest-direct.component.html',
  styleUrls: ['./invest-direct.component.css']
})
export class InvestDirectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
