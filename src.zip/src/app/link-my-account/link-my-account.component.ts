import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-link-my-account',
  templateUrl: './link-my-account.component.html',
  styleUrls: ['./link-my-account.component.css']
})
export class LinkMyAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
