import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invest-sip',
  templateUrl: './invest-sip.component.html',
  styleUrls: ['./invest-sip.component.css']
})
export class InvestSIPComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
