import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GroupsComponent } from './groups/groups.component';
import { ContactsListComponent } from './contacts-list/contacts-list.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { SearchContactComponent } from './search-contact/search-contact.component';
import { LoginComponent } from './login/login.component';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { ViewinvestmentsComponent } from './viewinvestments/viewinvestments.component';
import { ViewTransactionsComponent } from './view-transactions/view-transactions.component';
import { CustomerGoldComponent } from './customer-gold/customer-gold.component';
import { CustomerSilverComponent } from './customer-silver/customer-silver.component';
import { InvestDirectComponent } from './invest-direct/invest-direct.component';
import { InvestSIPComponent } from './invest-sip/invest-sip.component';
import { WithdrawMFComponent } from './withdraw-mf/withdraw-mf.component';
import { LinkMyAccountComponent } from './link-my-account/link-my-account.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    GroupsComponent,
    ContactsListComponent,
    ContactFormComponent,
    SearchContactComponent,
    LoginComponent,
    CustomerDashboardComponent,
    ViewinvestmentsComponent,
    ViewTransactionsComponent,
    CustomerGoldComponent,
    CustomerSilverComponent,
    InvestDirectComponent,
    InvestSIPComponent,
    WithdrawMFComponent,
    LinkMyAccountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
