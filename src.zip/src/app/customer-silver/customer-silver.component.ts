import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-silver',
  templateUrl: './customer-silver.component.html',
  styleUrls: ['./customer-silver.component.css']
})
export class CustomerSilverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
