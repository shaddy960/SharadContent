import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerSilverComponent } from './customer-silver.component';

describe('CustomerSilverComponent', () => {
  let component: CustomerSilverComponent;
  let fixture: ComponentFixture<CustomerSilverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerSilverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerSilverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
