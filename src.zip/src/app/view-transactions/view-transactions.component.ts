import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-transactions',
  templateUrl: './view-transactions.component.html',
  styleUrls: ['./view-transactions.component.css']
})
export class ViewTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
