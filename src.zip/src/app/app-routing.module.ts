import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {DashboardComponent} from './dashboard/dashboard.component';
import {GroupsComponent} from './groups/groups.component';
import {ContactFormComponent} from './contact-form/contact-form.component';
import {SearchContactComponent} from './search-contact/search-contact.component';
import {ContactsListComponent} from './contacts-list/contacts-list.component';

import { from } from 'rxjs';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { ViewinvestmentsComponent } from './viewinvestments/viewinvestments.component';
import { ViewTransactionsComponent } from './view-transactions/view-transactions.component';
import { CustomerGoldComponent } from './customer-gold/customer-gold.component';
import { CustomerSilverComponent } from './customer-silver/customer-silver.component';
import { WithdrawMFComponent } from './withdraw-mf/withdraw-mf.component';
import { LinkMyAccountComponent } from './link-my-account/link-my-account.component';
import { InvestDirectComponent } from './invest-direct/invest-direct.component';
import { InvestSIPComponent } from './invest-sip/invest-sip.component';

const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'groups',component:GroupsComponent},
  {path:'contacts',component:ContactsListComponent},
  {path:'newContact',component:ContactFormComponent},
  {path:'editContact/:contactId',component:ContactFormComponent},
  {path:'search',component:SearchContactComponent},
  {path:'custDash',component:CustomerDashboardComponent},
  {path:'viewInvestment',component:ViewinvestmentsComponent},
  {path:'viewTransactions',component:ViewTransactionsComponent},
  {path:'custGold',component:CustomerGoldComponent},
  {path:'custSil',component:CustomerSilverComponent},
  {path:'withdraw',component:WithdrawMFComponent},
  {path:'linkMyacc',component:LinkMyAccountComponent},
  {path:'investDirect',component:InvestDirectComponent},
  {path:'investSip',component:InvestSIPComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
