import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:User;
  
  message:any;
  constructor(private custService:CustomerService) { 
    this.user = new User();
    this.message="Hello";
  }

  ngOnInit() {
  }

  verify(){
    console.log("here");
  this.custService.custLogin(this.user).subscribe(
    (data)=>{     
      this.message=data;},
     (err) => {this.message=err}
  );
  console.log("here2");
  }
}
