import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-gold',
  templateUrl: './customer-gold.component.html',
  styleUrls: ['./customer-gold.component.css']
})
export class CustomerGoldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
