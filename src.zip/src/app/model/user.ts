export class User{
    public userId:String;
    public password:String;
}