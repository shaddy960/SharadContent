import { GroupStatistics } from './group-statistics';

describe('GroupStatistics', () => {
  it('should create an instance', () => {
    expect(new GroupStatistics()).toBeTruthy();
  });
});
