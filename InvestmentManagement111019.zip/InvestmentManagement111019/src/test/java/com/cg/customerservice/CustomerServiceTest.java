package com.cg.customerservice;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;

import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.ClientService;
import com.cg.ibs.investment.service.ClientServiceImpl;
public class CustomerServiceTest {
	
	@Test
	public void viewInvestments() throws IBSException {
		ClientService clientService=new ClientServiceImpl();
		assertNotNull(clientService.viewInvestments("a"));
	}
	@Test
	public void buyGold() throws IBSException {
		ClientService clientService=new ClientServiceImpl();
		clientService.buyGold(10, "a");
		assertEquals(60,000,clientService.viewInvestments("a").getBalance());
		assertEquals(230,clientService.viewInvestments("a").getGoldunits());
		
		
		Assertions.assertThrows(IBSException.class, () -> {
			clientService.buyGold(100, "a"); });
		Assertions.assertThrows(IBSException.class, () -> {
			clientService.buyGold(-100, "a") ; });
		

		
	}

	
   
		
	
	
	
	
	
}
