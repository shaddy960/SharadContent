package com.cg.ibs.investment.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.cg.ibs.common.bean.AccountBean;
import com.cg.ibs.common.bean.CustomerBean;
import com.cg.ibs.common.bean.TransactionBean;
import com.cg.ibs.common.bean.TransactionType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.ErrorMessages;
import com.cg.ibs.investment.exception.IBSException;

public class InvestmentDaoImpl implements BankDao, ClientDao {
	
	static long count = Math.round(Math.random()*10000000);
	static Logger log = Logger.getLogger(InvestmentDaoImpl.class.getName());

	// Method to view Gold Price
	@Override
	public double viewGoldPrice() throws IBSException {
		double goldPrice = 0;
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_GOLD_PRICE);) {
			ResultSet resultSet = pst.executeQuery();
			if (resultSet.next()) {

				goldPrice = resultSet.getDouble("gold_price");
			}
			resultSet.close();
			
			log.info("Latest gold Price");
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return goldPrice;
	}

	// Method to view Silver Price
	@Override
	public double viewSilverPrice() throws IBSException {
		double silverPrice=0;
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_SILVER_PRICE);) {
			

			ResultSet resultSet = pst.executeQuery();
			if (resultSet.next()) {

				silverPrice = resultSet.getDouble("silver_price");
			}
		
			resultSet.close();
			log.info("Latest silver price");
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

		return silverPrice;
	}

	// Method to view Investments of the Customer
	@Override
	public InvestmentBean viewInvestments(String uci) throws IBSException {
		InvestmentBean investmentBean = new InvestmentBean();
		Set<MutualFund> mFunds = new HashSet<>();

		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_MY_INVESTMENTS);
				PreparedStatement pst1 = con.prepareStatement(QueryMapper.VIEW_MY_MF);
				PreparedStatement pst2 = con.prepareStatement(QueryMapper.VIEW_MY_BALANCE);) {
			pst.setString(1, uci);
			pst1.setString(1, uci);
			ResultSet rs = pst.executeQuery();
			ResultSet rs1 = pst1.executeQuery();
			if (rs.next()) {

				investmentBean.setUCI(rs.getString("uci"));
				investmentBean.setGoldunits(rs.getDouble("gold_units"));
				investmentBean.setSilverunits(rs.getDouble("silver_units"));
				investmentBean.setAccount_Number(rs.getString("account_number"));

			}
			while (rs1.next()) {
				MutualFund mfc = new MutualFund();
				mfc.setmfid(rs1.getInt("mf_id"));
				mfc.setMfUnits(rs1.getDouble("mf_units"));
				mfc.setMfAmount(rs1.getDouble("mf_amount"));
				mfc.setTitle(rs1.getString("mf_title"));
				mfc.setNav(rs1.getDouble("nav"));
				mfc.setOpeningDate(rs1.getDate("opening_date").toLocalDate());
				if (rs1.getDate("closing_date") != null) {
					mfc.setClosingDate(rs1.getDate("closing_date").toLocalDate());
				} else {
					mfc.setClosingDate(null);
				}
				mFunds.add(mfc);
			}
			investmentBean.setFunds(mFunds);
			pst2.setString(1, investmentBean.getAccount_Number());
			ResultSet rs2 = pst2.executeQuery();
			if (rs2.next()) {

				investmentBean.setBalance(rs2.getDouble("current_balance"));
			}
			investmentBean.setTransactionList(getTransactions(investmentBean.getAccount_Number()));
			rs.close();
			rs1.close();
			rs2.close();
			log.info("Investments of customer received");
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		
		return investmentBean;
	}

	// Method to view Mutual Fund plans provided by the bank
	@Override
	public HashMap<Integer, BankMutualFund> viewMF() throws IBSException {
		HashMap<Integer, BankMutualFund> mutualFunds=new HashMap<>();
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_BANK_MF)) {
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				BankMutualFund bk = new BankMutualFund(rs.getInt("mf_plan_id"), rs.getString("mf_title"),
						rs.getDouble("nav"));
				mutualFunds.put(rs.getInt("mf_plan_id"), bk);
			}
			log.info("Mutual Funds received successfully");
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return mutualFunds;
	}

	//// Method to update transactions of the customer

	// Method to update Gold Price
	@Override
	public boolean updateGoldPrice(double x) throws IBSException {
		boolean status = false;
		
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst1 = con.prepareStatement(QueryMapper.UPDATE_GOLD_PRICE);) {
			pst1.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
			
			
				pst1.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
				pst1.setDouble(2, x);
				pst1.executeUpdate();
				status = true;
		

			log.info("Gold Price Updated Successfully");
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return status;

	}

	// Method to update Silver Price
	@Override
	public boolean updateSilverPrice(double y) throws IBSException {
		boolean status = false;
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst1 = con.prepareStatement(QueryMapper.UPDATE_SILVER_PRICE);) {
			
		

			
				
				pst1.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
				pst1.setDouble(2, y);
				pst1.executeUpdate();
				status = true;
			
			log.info("Silver Price Updated successfully");

		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return status;

	}

	// Method to add new Mutual Fund plans
	@Override
	public boolean addMF(BankMutualFund mutualFund) throws IBSException {
		boolean status = false;
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.ADD_MF);){
			pst.setLong(1,mutualFund.getmfid() );
			pst.setString(2, mutualFund.getTitle());
			pst.setDouble(3, mutualFund.getNav());
			pst.executeUpdate();
			status=true;
			
			log.info("New Mutual Fundded by Bank");
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);			
		} 
		return status;
	}

	// Method to view details of Bank representative
	

	// Method to update Gold and Silver units of the customer
	@Override
	public void updateUnits(String uci, double units, InvestmentBean investmentBean, int choice) throws IBSException {
		InvestmentBean temp = viewInvestments(uci);
		if (choice == 1) {
			try (Connection con = ConnectionProvider.getInstance().getConnection();) {
				con.setAutoCommit(false);
				try (PreparedStatement pst = con.prepareStatement(QueryMapper.GOLD_UNITS);
						PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.BALANCE);
						PreparedStatement pst1 = con.prepareStatement(QueryMapper.INSERT_TRANSACTION);) {
					pst.setString(2, uci);
					pst.setDouble(1, temp.getGoldunits() + units);
					pst.executeUpdate();

					preparedStatement.setString(2, temp.getAccount_Number());
					preparedStatement.setDouble(1, temp.getBalance() - units * viewGoldPrice());
					preparedStatement.executeUpdate();
					long transId = 10010 + count;
					count++;
					pst1.setString(1, temp.getAccount_Number());
					pst1.setString(2, Long.toString(transId));
					pst1.setString(3, TransactionType.DEBIT.toString());
					pst1.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
					pst1.setDouble(5, units * viewGoldPrice());
					pst1.setString(6, Description.GOLD.toString());
					pst1.setDouble(7, units);
					pst1.setDouble(8, viewGoldPrice());
					pst1.executeUpdate();
					con.commit();
					log.info("Gold Bought");
				} catch (SQLException e) {
					con.rollback();
					log.error(e);
					throw new IBSException(ErrorMessages.INTERNAL_ERROR);	
				}
			} catch (SQLException | IOException e) {
				log.error(e);
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);	
			}

		} else if (choice == 2) {
			try (Connection con = ConnectionProvider.getInstance().getConnection();) {
				con.setAutoCommit(false);
				try (PreparedStatement pst5 = con.prepareStatement(QueryMapper.GOLD_UNITS);
						PreparedStatement pst1 = con.prepareStatement(QueryMapper.INSERT_TRANSACTION);
						PreparedStatement preparedStatement7 = con.prepareStatement(QueryMapper.BALANCE);) {
					pst5.setString(2, uci);
					pst5.setDouble(1, temp.getGoldunits() - units);
					pst5.executeUpdate();
					preparedStatement7.setString(2, temp.getAccount_Number());
					preparedStatement7.setDouble(1, temp.getBalance() + units * viewGoldPrice());
					preparedStatement7.executeUpdate();
					long transId = 20010 + count;
					count++;
					pst1.setString(1, temp.getAccount_Number());
					pst1.setString(2, Long.toString(transId));
					pst1.setString(3, TransactionType.CREDIT.toString());
					pst1.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
					pst1.setDouble(5, units * viewGoldPrice());
					pst1.setString(6, Description.GOLD.toString());
					pst1.setDouble(7, units);
					pst1.setDouble(8, viewGoldPrice());
					pst1.executeUpdate();
					con.commit();
					log.info("Gold Sold");
				} catch (SQLException e) {
					con.rollback();
					log.error(e);
					throw new IBSException(ErrorMessages.INTERNAL_ERROR);	
				}
			} catch (SQLException | IOException e) {
				log.error(e);
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);	
			}
		} else if (choice == 3) {
			try (Connection con = ConnectionProvider.getInstance().getConnection();) {
				con.setAutoCommit(false);
				try (PreparedStatement pst = con.prepareStatement(QueryMapper.SILVER_UNITS);
						PreparedStatement pst1 = con.prepareStatement(QueryMapper.INSERT_TRANSACTION);
						PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.BALANCE);) {
					pst.setString(2, uci);
					pst.setDouble(1, temp.getSilverunits() + units);
					pst.executeUpdate();
					preparedStatement.setString(2, temp.getAccount_Number());
					preparedStatement.setDouble(1, temp.getBalance() - units * viewSilverPrice());
					preparedStatement.executeUpdate();
					long transId = 30010 + count;
					count++;
					pst1.setString(1, temp.getAccount_Number());
					pst1.setString(2, Long.toString(transId));
					pst1.setString(3, TransactionType.DEBIT.toString());
					pst1.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
					pst1.setDouble(5, units * viewSilverPrice());
					pst1.setString(6, Description.SILVER.toString());
					pst1.setDouble(7, units);
					pst1.setDouble(8, viewSilverPrice());
					pst1.executeUpdate();
					con.commit();
					log.info("Silver Bought");
				} catch (SQLException e) {
					con.rollback();
					log.error(e);
					throw new IBSException(ErrorMessages.INTERNAL_ERROR);	
				}
			} catch (SQLException | IOException e) {
				e.printStackTrace();
			}
		} else if (choice == 4) {
			try (Connection con = ConnectionProvider.getInstance().getConnection();) {
				con.setAutoCommit(false);
				try (PreparedStatement pst = con.prepareStatement(QueryMapper.SILVER_UNITS);
						PreparedStatement pst1 = con.prepareStatement(QueryMapper.INSERT_TRANSACTION);
						PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.BALANCE);) {
					pst.setString(2, uci);
					pst.setDouble(1, temp.getSilverunits() - units);
					pst.executeUpdate();
					preparedStatement.setString(2, temp.getAccount_Number());
					preparedStatement.setDouble(1, temp.getBalance() + units * viewSilverPrice());
					preparedStatement.executeUpdate();
					long transId = 40010 + count;
					count++;
					pst1.setString(1, temp.getAccount_Number());
					pst1.setString(2, Long.toString(transId));
					pst1.setString(3, TransactionType.CREDIT.toString());
					pst1.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
					pst1.setDouble(5, units * viewSilverPrice());
					pst1.setString(6, Description.SILVER.toString());
					pst1.setDouble(7, units);
					pst1.setDouble(8, viewSilverPrice());
					pst1.executeUpdate();
					con.commit();
					log.info("Silver Sold");
				} catch (SQLException e) {
					con.rollback();
					log.error(e);
					throw new IBSException(ErrorMessages.INTERNAL_ERROR);	
				}
			} catch (SQLException | IOException e) {
				log.error(e);
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);	
			}
		}

	}

	// Method to invest in Mutual funds for a customer
	@Override
	public void addMFInvestments(double mfAmount, int mfPlanId, InvestmentBean investmentBean) throws IBSException {
		 double nav= viewMF().get(mfPlanId).getNav();
		 try (	          
	            Connection con = ConnectionProvider.getInstance().getConnection();
	            PreparedStatement pst = con.prepareStatement(QueryMapper.INVEST_MF);
				 PreparedStatement pst1 = con.prepareStatement(QueryMapper.INSERT_TRANSACTION);
				 PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.BALANCE)){
			 
	            pst.setString(1,investmentBean.getUCI());
	            pst.setLong(2, count);
	            pst.setInt(3, mfPlanId);
	            pst.setDouble(4, mfAmount/nav);
	            pst.setDouble(5, mfAmount);
	            pst.setDate(6, java.sql.Date.valueOf(LocalDate.now()));
	            pst.setDate(7, null);
	            pst.executeUpdate();
	            long transId = 50010 + count;
				count++;
				pst1.setString(1, investmentBean.getAccount_Number());
				pst1.setString(2, Long.toString(transId));
				pst1.setString(3, TransactionType.DEBIT.toString());
				pst1.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
				pst1.setDouble(5, mfAmount);
				pst1.setString(6, Description.MUTUAL_FUND.toString());
				pst1.setDouble(7, mfAmount/nav);
				pst1.setDouble(8, nav);
				pst1.executeUpdate();
				preparedStatement.setString(2, investmentBean.getAccount_Number());
				preparedStatement.setDouble(1, investmentBean.getBalance() -mfAmount);
				preparedStatement.executeUpdate();
				log.info("New Mutual Added to Customer Investments");
	           
	        } catch (SQLException | IOException e) {
	        	log.error(e);
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);	
	        }

	}

	// Method to withdraw Mutual fund of a customer
	@Override
	public void withdrawMF(String uci, MutualFund mutualFund, InvestmentBean investmentBean) throws IBSException {
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.WITHDRAW_MF);
				 PreparedStatement pst1 = con.prepareStatement(QueryMapper.INSERT_TRANSACTION);
				PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.BALANCE);){
			pst.setDate(1, Date.valueOf(LocalDate.now()));
			pst.setInt(2, mutualFund.getmfid());
			pst.executeUpdate();
			long transId = 50010 + count;
			count++;
			pst1.setString(1, investmentBean.getAccount_Number());
			pst1.setString(2, Long.toString(transId));
			pst1.setString(3, TransactionType.CREDIT.toString());
			pst1.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
			pst1.setDouble(5, mutualFund.getMfAmount());
			pst1.setString(6, Description.MUTUAL_FUND.toString());
			pst1.setDouble(7, mutualFund.getMfUnits());
			pst1.setDouble(8, mutualFund.getNav());
			pst1.executeUpdate();
			preparedStatement.setString(2, investmentBean.getAccount_Number());
			preparedStatement.setDouble(1, investmentBean.getBalance()+mutualFund.getMfAmount());
			preparedStatement.executeUpdate();
			log.info("Mutual Fund Withdrawn successfully");
		} catch (SQLException | IOException e) {			
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);	
		} 

	}

	// Method to save Transactions history of a customer
	@Override
	public TreeSet<TransactionBean> getTransactions(String accountNum) throws IBSException {
		TreeSet<TransactionBean> trSet = new TreeSet<>(new TransactionsComparator());
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.VIEW_MY_TRANSACTIONS);) {
			pst.setString(1, accountNum);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {

				TransactionBean ts = new TransactionBean();
				ts.setTransactionId(new BigInteger(rs.getString("trans_id")));
				ts.setTransactionType(TransactionType.valueOf(rs.getString("trans_type")));
				ts.setTransactionDate(rs.getTimestamp("trans_date_time").toLocalDateTime());
				ts.setTransactionAmount(rs.getBigDecimal("amount"));
				ts.setPrice(rs.getDouble("price_per_unit"));
				ts.setDes(Description.valueOf(rs.getString("description")));
				ts.setUnits(rs.getDouble("units"));
				ts.setAccountNumber(new BigInteger(rs.getString("account_number")));
				trSet.add(ts);

			}
			log.info("Transactions received successfully");
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);	
		}
		return trSet;

	}
	@Override
	public String getUcibyUseriD(String userId) throws IBSException {
		String uci = null;
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.GET_UCI);) {
			pst.setString(1, userId);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				uci = rs.getString("uci");

			}
			rs.close();
			log.info("UCI received successfully");
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

		return uci;

	}

	@Override
	public CustomerBean getCustomer(String userid) throws IBSException {
		CustomerBean cs = new CustomerBean();
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.GET_CUSTOMER)) {
			pst.setString(1, userid);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				cs.setUserId(rs.getString("user_id"));
				cs.setPassword(rs.getString("password"));
				cs.setUCI(rs.getString("uci"));

			}
			
			rs.close();
			log.info("Cutomer details recieved successfully");
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return cs;
	}
    
	@Override
	public ArrayList<AccountBean> getAccountsByUci(String uci) throws IBSException {

		ArrayList<AccountBean> acc = new ArrayList<>();

		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.GET_ACCOUNT_BY_UCI);) {
			pst.setString(1, uci);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				BigInteger uciNum = new BigInteger(rs.getString("uci"));
				BigInteger accNum = new BigInteger(rs.getString("account_number"));
				BigDecimal bal = BigDecimal.valueOf(rs.getDouble("current_balance"));
				AccountBean acb = new AccountBean(accNum, bal, uciNum);
				acc.add(acb);

			}
			rs.close();
			log.info("Account list recieved successfully");
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}
		return acc;
	}

	@Override
	public CustomerBean getBankAdmin(String userid) throws IBSException {
		CustomerBean cs = new CustomerBean();
		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.GET_BANK_ADMIN)) {
			pst.setString(1, userid);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				cs.setUserId(rs.getString("admin_id"));
				cs.setPassword(rs.getString("password"));
				
			}
			log.info("Bank Admin Details Received Successfully");
			rs.close();
		} catch (SQLException | IOException e) {
			log.error(e);
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return cs;
	}
	@Override
    public void linkNewAccount(BigInteger accountNumber,String uci) throws IBSException  {
        try (Connection con = ConnectionProvider.getInstance().getConnection();
                PreparedStatement pst = con.prepareStatement(QueryMapper.SET_MY_ACCOUNT)){
        pst.setString(2, uci);
        pst.setString(1, accountNumber.toString());
        pst.executeUpdate();
        } catch (IOException |SQLException e) {
            log.error(e);
            throw new IBSException("");           
        }
       
    }
	

}
