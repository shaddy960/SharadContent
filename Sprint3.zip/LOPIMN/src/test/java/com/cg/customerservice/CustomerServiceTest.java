package com.cg.customerservice;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;

import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;

import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.BankServiceImpl;
import com.cg.ibs.investment.service.ClientService;
import com.cg.ibs.investment.service.ClientServiceImpl;
public class CustomerServiceTest {
	

	 ClientService clientService;
	 BankService bankService;
	 
	@BeforeEach
	void doIt() {
		clientService = new ClientServiceImpl();
		bankService = new BankServiceImpl();
	}

	@Test
	public void viewInvestments() {
		
		try {
			assertNotNull(clientService.viewInvestments("a"));
		} catch (IBSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("a",clientService.viewInvestments("a").getUserId() );
		} catch (IBSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void viewInvestmentsCheckNull(){
		
		Assertions.assertThrows(IBSException.class, () -> {
			clientService.viewInvestments("null") ; });
	}
	
	@Test
	@DisplayName("checking balance/buy gold")
	public void buyGold() throws IBSException  {
		
		assertEquals(4000, clientService.viewGoldPrice());
		try {
			clientService.buyGold(10.0, "a");
			assertEquals(60000, clientService.viewInvestments("a").getBalance());
		} catch (IBSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void checkSufficientBalance(){
		Assertions.assertThrows(IBSException.class, () -> {
			clientService.buyGold(100, "a"); });}
		
	@Test
	public void checkNegativeInputOfGoldUniits() {
				Assertions.assertThrows(IBSException.class, () -> {
			clientService.buyGold(-100, "a") ; });
		
	}
	
	public void checkSellGold() {
		try {
			clientService.sellGold(10, "a");
			assertEquals(101000,clientService.viewInvestments("a").getBalance());
			assertEquals(210,clientService.viewInvestments("a").getGoldunits());}
			catch(IBSException e) {
				System.out.println(e.getMessage());
			}
		
	}

	@Test
	public void checkSufficientGoldUnits(){
		assertThrows(IBSException.class, () -> clientService.sellGold(300, "a"));
		}
	
	@Test
	public void checkNegativeInputOfGoldUniitsSelling() {
		ClientService clientService=new ClientServiceImpl();
		assertThrows(IBSException.class, () -> {
			clientService.sellGold(-100, "a") ; });
		
	}
	
	
	/*@Test
	public void checkInvestMFID() {
		try {
			clientService.investMF(2000, "a", 10001);
		MutualFund mutualFund=new MutualFund(10001, "IBS Basic Plan", 200, 50, LocalDate.now(), null, true);
		assertEquals(true,clientService.viewInvestments("a").getFunds().contains(mutualFund) );
			
		} catch (IBSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		
	}*/
	
	@Test
	public void checkSufficientBalance1(){			
	assertThrows(IBSException.class, () -> clientService.investMF(200000, "a", 10003));
	}
	
	@Test
	public void checkmfId(){			
	//assertThrows(IBSException.class, () -> clientService.viewInvestments("a").getFunds().contains(o));
	
	}
	
	@Test
	@Disabled
	public void checkInvestMFBalance() {
		try {
			clientService.investMF(2000, "a", 10001);
			assertEquals(98000, clientService.viewInvestments("a").getBalance());
			
		} catch (IBSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
   
		
	
	
	
	
	
}
