package com.cg.ibs.investment.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.cg.ibs.common.bean.AccountBean;
import com.cg.ibs.common.bean.CustomerBean;
import com.cg.ibs.common.bean.TransactionBean;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.dao.ClientDao;
import com.cg.ibs.investment.dao.ConnectionProvider;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.dao.QueryMapper;
import com.cg.ibs.investment.exception.ErrorMessages;
import com.cg.ibs.investment.exception.IBSException;

public class ClientServiceImpl implements ClientService {
	private static final Logger LOGGER = Logger.getLogger(ClientServiceImpl.class);
	

	// Declaring an object of Client DAO
	ClientDao clientdao = new InvestmentDaoImpl();

	// To view Mutual Fund plans of the customer
	@Override
	public HashMap<Integer, BankMutualFund> viewMFPlans() {
		try {
			return (clientdao.viewMF());
		} catch (IBSException e) {
			LOGGER.error(e);
		}
		return null;
	}

	// To view Gold price
	@Override
	public double viewGoldPrice() throws IBSException {
		return (clientdao.viewGoldPrice());

	}

	// To view Silver price
	@Override
	public double viewSilverPrice() {
		return (clientdao.viewSilverPrice());

	}

	// To buy gold
	@Override
	public void buyGold(double gunits, String userid) throws IBSException {
		String uci = getUcibyUseriD(userid);
		if (gunits > 0) {
			InvestmentBean investmentBean = clientdao.viewInvestments(uci);
			if (investmentBean.getBalance() >= gunits * clientdao.viewGoldPrice()) {
				clientdao.updateUnits(uci, gunits, investmentBean, 1);

			} else {

				throw new IBSException(ErrorMessages.INSUFF_BALANCE_MESSAGE);
			}

		} else {
			throw new IBSException(ErrorMessages.INVALID_UNITS_MESSAGE);

		}
	}

	// To Sell Gold
	@Override
	public void sellGold(double gunits, String userId) throws IBSException {
		String uci = getUcibyUseriD(userId);
		InvestmentBean investmentBean = clientdao.viewInvestments(uci);
		if (gunits > 0) {
			if (gunits < investmentBean.getGoldunits()) {
				clientdao.updateUnits(uci, gunits, investmentBean, 2);

			} else {
				throw new IBSException(ErrorMessages.INSUFF_BALANCE_MESSAGE);
			}

		} else {
			throw new IBSException(ErrorMessages.INVALID_UNITS_MESSAGE);
		}

	}

	// To buy Silver
	@Override
	public void buySilver(double sunits, String userId) throws IBSException {
		String uci = getUcibyUseriD(userId);
		if (sunits > 0) {
			InvestmentBean investmentBean = clientdao.viewInvestments(uci);
			if (investmentBean.getBalance() >= sunits * clientdao.viewSilverPrice()) {

				clientdao.updateUnits(uci, sunits, investmentBean, 3);

			} else {
				throw new IBSException(ErrorMessages.INSUFF_BALANCE_MESSAGE);
			}

		} else {
			throw new IBSException(ErrorMessages.INVALID_UNITS_MESSAGE);
		}

	}

	// To Sell Silver
	@Override
	public void sellSilver(double sunits, String userId) throws IBSException {
		String uci = getUcibyUseriD(userId);
		InvestmentBean investmentBean = clientdao.viewInvestments(uci);
		if (sunits > 0) {
			if (sunits < investmentBean.getSilverunits()) {
				clientdao.updateUnits(uci, sunits, investmentBean, 4);

			} else {
				throw new IBSException(ErrorMessages.INSUFF_BALANCE_MESSAGE);
			}

		} else {
			throw new IBSException(ErrorMessages.INVALID_UNITS_MESSAGE);
		}
	}

	// To invest in Mutual Funds
	@Override
	public void investMF(double mfAmount, String userId, Integer mfId) throws IBSException {
		String uci = getUcibyUseriD(userId);
		if (mfAmount > 0) {
			if (clientdao.viewMF().containsKey(mfId)) {
				InvestmentBean investmentBean = null;

				investmentBean = clientdao.viewInvestments(uci);

				if (investmentBean.getBalance() >= mfAmount) {
					clientdao.addMFInvestments(mfAmount, mfId, investmentBean);

				} else {
					throw new IBSException(ErrorMessages.INSUFF_BALANCE_MESSAGE);
				}
			} else {
				throw new IBSException(ErrorMessages.INVALID_DETAILS_MESSAGE);
			}
		} else {
			throw new IBSException(ErrorMessages.INVALID_AMOUNT_MESSAGE);
		}
	}

	// To withdraw from Mutual Funds
	@Override
	public void withdrawMF(String userId, MutualFund mutualFund) throws IBSException {
		String uci = getUcibyUseriD(userId);
		if (clientdao.viewInvestments(uci) != null) {
			InvestmentBean investmentBean = clientdao.viewInvestments(uci);
			clientdao.withdrawMF(uci, mutualFund, investmentBean);

			// clientdao.updateTransaction(userId, 2, investmentBean,
			// mutualFund.getMfAmount());

		} else {
			throw new IBSException(ErrorMessages.INVALID_DETAILS_MESSAGE);
		}
	}

	// To view Investments of a customer
	/**
	 * 
	 * 
	 */
	@Override
	public InvestmentBean viewInvestments(String userid) throws IBSException {
		String uci = getUcibyUseriD(userid);
		if (clientdao.viewInvestments(uci) != null) {
			LOGGER.info("ClientDao object exists");
			return clientdao.viewInvestments(uci);

		} else {
			LOGGER.error("no such account exists" + ErrorMessages.INVALID_ACCOUNT_MESSAGE);
			throw new IBSException(ErrorMessages.INVALID_ACCOUNT_MESSAGE);

		}

	}

	// To validate login details of a customer
	@Override
	public boolean validateCustomer(String userId, String password) {
		CustomerBean cs = clientdao.getCustomer(userId);
		try {
			String uci = getUcibyUseriD(userId);
			if (cs != null) {
				if (userId.equals(cs.getUserId())) {

					String correctPassword = cs.getPassword();
					if (password.equals(correctPassword)) {
						return true;
					}
				}
			}
		} catch (IBSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	// To generate transaction history of a customer
	@Override
	public TreeSet<TransactionBean> getTransactions(String userId) {
		return clientdao.getTransactions(userId);
	}

	public void viewMyAccounts(ArrayList<AccountBean> accBean) {
		int i = 0;
		for (AccountBean accountBean : accBean) {
			System.out.println(i + " " + accountBean.getAccountNumber() + " " + accountBean.getCurrentBalance() + " "
					+ accountBean.getUci());
			i++;
		}

	}

	public AccountBean linkMyAccount(ArrayList<AccountBean> accBean, int i) {
		AccountBean bean = new AccountBean();
		bean = accBean.get(i);
		return bean;
	}

	public static String getUcibyUseriD(String userId) throws IBSException {
		String uci = null;
		try {
			Connection con = ConnectionProvider.getInstance().getConnection();
			PreparedStatement pst = con.prepareStatement(QueryMapper.GET_UCI);
			pst.setString(1, userId);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				uci = rs.getString("uci");

			}
		} catch (SQLException | IOException e) {
			throw new IBSException(e.getMessage());

		}

		return uci;

	}

}
