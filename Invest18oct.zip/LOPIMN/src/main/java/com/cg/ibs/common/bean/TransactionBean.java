package com.cg.ibs.common.bean;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.cg.ibs.investment.dao.Description;

public class TransactionBean {
	private BigInteger transactionId;
	private TransactionType transactionType;
	private LocalDateTime transactionDate;
	private BigDecimal transactionAmount;
	private double price;
	private Description des;
	private double units;
	private BigInteger accountNumber;
	public TransactionBean() {
		super();
	}
	public BigInteger getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(BigInteger transactionId) {
		this.transactionId = transactionId;
	}
	public TransactionType getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}
	public LocalDateTime getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDateTime transactionDate) {
		this.transactionDate = transactionDate;
	}
	public BigDecimal getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(BigDecimal transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Description getDes() {
		return des;
	}
	public void setDes(Description des) {
		this.des = des;
	}
	public double getUnits() {
		return units;
	}
	public void setUnits(double units) {
		this.units = units;
	}
	public BigInteger getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(BigInteger accountNumber) {
		this.accountNumber = accountNumber;
	}
	@Override
	public String toString() {
		return "TransactionBean [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", transactionAmount=" + transactionAmount + ", price="
				+ price + ", des=" + des + ", units=" + units + ", accountNumber=" + accountNumber + "]";
	}
	public TransactionBean(BigInteger transactionId, TransactionType transactionType, LocalDateTime transactionDate,
			BigDecimal transactionAmount, double price, Description des, double units, BigInteger accountNumber) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.transactionAmount = transactionAmount;
		this.price = price;
		this.des = des;
		this.units = units;
		this.accountNumber = accountNumber;
	}
	

}



