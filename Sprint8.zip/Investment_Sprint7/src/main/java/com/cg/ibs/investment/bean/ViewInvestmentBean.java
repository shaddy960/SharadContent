package com.cg.ibs.investment.bean;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Set;

import com.cg.ibs.investment.model.MutualView;

public class ViewInvestmentBean {
	    private BigInteger Uci;
	    private Double goldUnits;
	    private Double silverUnits;
	    private List<MutualView> sipfunds;
	    private List<MutualView> dirFunds;
	    private BigInteger accountNumber;
	    private BigDecimal balance;
	    private Double silverAsset;
	    private Double goldAsset;
	    private Double mfAssest;
	    
	    
	    
	    public Double getMfAssest() {
			return mfAssest;
		}
		public void setMfAssest(Double mfAssest) {
			this.mfAssest = mfAssest;
		}
		public Double getSilverAsset() {
			return silverAsset;
		}
		public void setSilverAsset(Double silverAsset) {
			this.silverAsset = silverAsset;
		}
		public Double getGoldAsset() {
			return goldAsset;
		}
		public void setGoldAsset(Double goldAsset) {
			this.goldAsset = goldAsset;
		}
		public ViewInvestmentBean() {
	        super();
	    }
	    public BigInteger getUci() {
	        return Uci;
	    }
	    public void setUci(BigInteger uci) {
	        Uci = uci;
	    }
	    public Double getGoldUnits() {
	        return goldUnits;
	    }
	    public void setGoldUnits(Double goldUnits) {
	        this.goldUnits = goldUnits;
	    }
	    public Double getSilverUnits() {
	        return silverUnits;
	    }
	    public void setSilverUnits(Double silverUnits) {
	        this.silverUnits = silverUnits;
	    }
	    
	    public BigInteger getAccountNumber() {
	        return accountNumber;
	    }
	    public void setAccountNumber(BigInteger accountNumber) {
	        this.accountNumber = accountNumber;
	    }
	    public BigDecimal getBalance() {
	        return balance;
	    }
	    public void setBalance(BigDecimal balance) {
	        this.balance = balance;
	    }
		public List<MutualView> getSipfunds() {
			return sipfunds;
		}
		public void setSipfunds(List<MutualView> sipfunds) {
			this.sipfunds = sipfunds;
		}
		public List<MutualView> getDirFunds() {
			return dirFunds;
		}
		public void setDirFunds(List<MutualView> dirFunds) {
			this.dirFunds = dirFunds;
		}
		
	    
	    
}
