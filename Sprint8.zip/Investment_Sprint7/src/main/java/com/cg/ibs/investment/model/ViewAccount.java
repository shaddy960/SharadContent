package com.cg.ibs.investment.model;

import java.math.BigDecimal;
import java.math.BigInteger;

public class ViewAccount {
	private BigInteger accNum;
	private BigDecimal currentBalance;
	
	public BigInteger getAccNum() {
		return accNum;
	}
	public void setAccNum(BigInteger accNum) {
		this.accNum = accNum;
	}
	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}
	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}
	
	
}
