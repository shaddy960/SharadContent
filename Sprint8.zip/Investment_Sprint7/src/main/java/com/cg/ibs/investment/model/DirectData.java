package com.cg.ibs.investment.model;

public class DirectData {
	private Integer mfPlanId;
	private double mfAmount;
	public Integer getMfPlanId() {
		return mfPlanId;
	}
	public void setMfPlanId(Integer mfPlanId) {
		this.mfPlanId = mfPlanId;
	}
	public double getMfAmount() {
		return mfAmount;
	}
	public void setMfAmount(double mfAmount) {
		this.mfAmount = mfAmount;
	}
	
	
}
