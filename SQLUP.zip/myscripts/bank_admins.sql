CREATE TABLE bank_Admins(ADMIN_ID VARCHAR2(20) PRIMARY KEY, PASSWORD VARCHAR2(15) NOT NULL);

 

INSERT INTO Bank_Admins Values('id1', 'pass1');  

 

INSERT INTO Bank_Admins Values('id2', 'pass2');  