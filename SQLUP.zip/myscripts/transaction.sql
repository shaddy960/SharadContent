create table Transaction (
    account_number number(11) NOT NULL,
    trans_id number(10) PRIMARY KEY,
    trans_type varchar(8) NOT NULL,
    trans_date_time TIMESTAMP NOT NULL,
    amount number(20,2) NOT NULL,
    description varchar(15) NOT NULL,
    units number(10,2) NOT NULL,
    price_per_unit number(20,2) NOT NULL,
    FOREIGN KEY(account_number) REFERENCES accounts(account_number)	
);
INSERT INTO transaction VALUES(12345678901,1010101,'DEBIT',CURRENT_TIMESTAMP,30000,'GOLD',10.0,3000);
 