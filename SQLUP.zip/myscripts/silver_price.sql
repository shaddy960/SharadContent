create table silver_price(update_date DATE PRIMARY KEY,silver_price number(10,2) NOT NULL);

insert into silver_price values('15-OCT-2019',280.25);

insert into silver_price values('16-OCT-2019',295.00);