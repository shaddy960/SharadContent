create table investment_bean(uci number(16) PRIMARY KEY,account_number number(11) ,gold_units number(10,2) DEFAULT 0.00,silver_units number(10,2) DEFAULT 0.00,FOREIGN KEY(account_number) REFERENCES accounts(account_number));

insert into investment_bean values(5555111151513301,12345678901,50.00,158.5);

insert into investment_bean values(5555111151511001,12345678903,27.75,378.5);