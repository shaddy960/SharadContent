create table mutual_fund(uci number(16) ,mf_id number(3) PRIMARY KEY,mf_plan_id number(5) ,mf_units number(10,2),mf_amount number(20,2),opening_date DATE,closing_date DATE ,FOREIGN KEY(uci) REFERENCES investment_bean(uci),FOREIGN KEY(mf_plan_id) REFERENCES BANK_MUTUAL_FUND(MF_PLAN_ID));

insert into mutual_fund values(5555111151513301,101,10001,270.00,9000.00,'19-NOV-2015',null);

insert into mutual_fund values(5555111151511001,102,10002,300.00,90000.00,'19-Jun-2005','20-MAY-2018');