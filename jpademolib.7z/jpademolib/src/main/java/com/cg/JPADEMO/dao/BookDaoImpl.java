package com.cg.JPADEMO.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.cg.JPADEMO.model.Book;
import com.cg.JPADEMO.util.JPAUtil;

public class BookDaoImpl implements BookDao {

	private EntityManager entityManager;

	public BookDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}

	public Book addBook(Book book) {
		entityManager.persist(book);
		return book;
	}

	public Book updateBook(Book book) {
		return entityManager.merge(book);
	}

	public Book getBookByBcode(Integer bcode) {
		return entityManager.find(Book.class, bcode);
	}

	public List<Book> getAllBooks() {
		CriteriaQuery<Book> query = entityManager.getCriteriaBuilder().createQuery(Book.class);
		Root<Book> bookRoot = query.from(Book.class);
		query.select(bookRoot);

		return entityManager.createQuery(query).getResultList();
	}

	public boolean removeBook(Integer bcode) {
		boolean isDeleted = false;
		Book book = getBookByBcode(bcode);
		if (null != book) {
			entityManager.remove(book);
			isDeleted=true;
		}
		return isDeleted;
	}

}
