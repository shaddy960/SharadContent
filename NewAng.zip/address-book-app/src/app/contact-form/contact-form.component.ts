import { Component, OnInit } from '@angular/core';
import { Contact } from '../model/contact';
import { ContactService } from '../service/contact.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Group } from '../model/group';
import { GroupService } from '../service/group.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {

  contact: Contact;
  isNew: boolean;
  groups: Group[];
  dobStr: string;

  constructor(
    private grppServ: GroupService,
    private contServ: ContactService,
    private actRt: ActivatedRoute,
    private router: Router) {
    this.contact = new Contact();
    this.isNew = true;
    this.groups = [];
    this.dobStr = (new Date()).toISOString().substr(0, 10);
  }

  ngOnInit() {

    this.grppServ.getAll().subscribe(
      (data) => { this.groups = data; }
    );

    let contactId = parseInt(this.actRt.snapshot.paramMap.get("contactId"));
    if (contactId) {
      this.contServ.getById(contactId).subscribe(
        (data) => {
          this.isNew = false;
          this.contact = data;
          this.dobStr = data.dateOfBirth.toISOString().substr(0, 10);
        }
      );
    }
  }

  save() {
    this.contact.dateOfBirth = new Date(this.dobStr);

    let obr =
      this.isNew ? this.contServ.add(this.contact) : this.contServ.update(this.contact);

    obr.subscribe(
      (data) => {
        this.router.navigateByUrl("/contacts");
      }
    );
  }
}
