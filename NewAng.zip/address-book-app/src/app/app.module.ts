import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GroupsComponent } from './groups/groups.component';
import { ContactsListComponent } from './contacts-list/contacts-list.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { SearchContactComponent } from './search-contact/search-contact.component';
import { LoginComponent } from './login/login.component';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { ViewinvestmentsComponent } from './viewinvestments/viewinvestments.component';
import { ViewTransactionsComponent } from './view-transactions/view-transactions.component';
import { CustomerGoldComponent } from './customer-gold/customer-gold.component';
import { CustomerSilverComponent } from './customer-silver/customer-silver.component';
import { InvestDirectComponent } from './invest-direct/invest-direct.component';
import { InvestSIPComponent } from './invest-sip/invest-sip.component';
import { WithdrawMFComponent } from './withdraw-mf/withdraw-mf.component';
import { LinkMyAccountComponent } from './link-my-account/link-my-account.component';
import { WithdrawDirComponent } from './withdraw-dir/withdraw-dir.component';
import { WithdrawSipComponent } from './withdraw-sip/withdraw-sip.component';
import { RemoveMfComponent } from './remove-mf/remove-mf.component';
import { BankLoginComponent } from './bank-login/bank-login.component';
import { BankMenuComponent } from './bank-menu/bank-menu.component';
import { ManageGoldComponent } from './manage-gold/manage-gold.component';
import { ManageSilverComponent } from './manage-silver/manage-silver.component';
import { ManageMfComponent } from './manage-mf/manage-mf.component';
import { ViewMfComponent } from './view-mf/view-mf.component';
import { UpdateNavComponent } from './update-nav/update-nav.component';

import { UpdateDirStatusComponent } from './update-dir-status/update-dir-status.component';
import { UpdateSipStatusComponent } from './update-sip-status/update-sip-status.component';
import { UpdateMinAmtDirComponent } from './update-min-amt-dir/update-min-amt-dir.component';
import { UpdateMinAmtSipComponent } from './update-min-amt-sip/update-min-amt-sip.component';

import { AddMfComponent } from './add-mf/add-mf.component';

import { ErrorBankComponent } from './error-bank/error-bank.component';
import { ErrorCustomerComponent } from './error-customer/error-customer.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    GroupsComponent,
    ContactsListComponent,
    ContactFormComponent,
    SearchContactComponent,
    LoginComponent,
    CustomerDashboardComponent,
    ViewinvestmentsComponent,
    ViewTransactionsComponent,
    CustomerGoldComponent,
    CustomerSilverComponent,
    InvestDirectComponent,
    InvestSIPComponent,
    WithdrawMFComponent,
    LinkMyAccountComponent,
    WithdrawDirComponent,
    WithdrawSipComponent,
    BankLoginComponent,
    BankMenuComponent,
    ManageGoldComponent,
    ManageSilverComponent,
    ManageMfComponent,
    ViewMfComponent,
    UpdateNavComponent,
    
    UpdateDirStatusComponent,
    UpdateSipStatusComponent,
    UpdateMinAmtDirComponent,
    UpdateMinAmtSipComponent,
    
    AddMfComponent,
    RemoveMfComponent,
    
    ErrorBankComponent,
    ErrorCustomerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
