import { Component, OnInit } from '@angular/core';
import { ViewAccount } from '../model/viewAccount';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';
import { Units } from '../model/units';

@Component({
  selector: 'app-link-my-account',
  templateUrl: './link-my-account.component.html',
  styleUrls: ['./link-my-account.component.css']
})
export class LinkMyAccountComponent implements OnInit {
  accounts:ViewAccount[];
  units:Units;
  constructor(private custSrv:CustomerService, private router:Router) {
    this.accounts=[];
    this.units=new Units();
   }

  ngOnInit() {
    this.getAllAcc();
  }
  getAllAcc(){
    console.log("Here in get");
    this.custSrv.getAccounts().subscribe(
      (data)=>this.accounts=data,
      (error)=>{
        this.custSrv.customerError=error;
        this.router.navigate(['/errorCustomer']);
      }
    );
  }
  linkAcc(){
    this.custSrv.linkMyAccount(this.units).subscribe(
      (data)=>{
        this.custSrv.customerMessage=data.msg;
        if(data.bool){
          this.router.navigate(['/custDash']);
        }else{
          
        }
      },
      (error)=>{
        this.custSrv.customerError=error;
        this.router.navigate(['/errorCustomer']);
      }
    );
  }

}
