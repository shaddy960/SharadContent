import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Statement } from '../model/statement';
import { Units } from '../model/units';
import { Router } from '@angular/router';



@Component({
  selector: 'app-customer-gold',
  templateUrl: './customer-gold.component.html',
  styleUrls: ['./customer-gold.component.css']
})
export class CustomerGoldComponent implements OnInit {
  stmt: Statement;
  gUnits: Units;
  msg: String;
  constructor(private custServ: CustomerService, private router:Router) {
    this.stmt = new Statement();
    this.gUnits = new Units();


  }

  ngOnInit() {

    this.gUnits.userId=sessionStorage.getItem("userId");
  }
  buy() {
   
    
    this.custServ.buyCustGold(this.gUnits).subscribe(
      (data) => {
        this.stmt = data;
        this.msg = data.msg;
        this.custServ.customerMessage=data.msg;
        if(this.stmt.bool){
          this.router.navigate(['/custDash']);
        }else{
          this.custServ.customerError=data.msg;
          this.router.navigate(['/errorCustomer']);
        }
        
      },
      (error)=>{
       this.custServ.customerError=error;
        this.router.navigate(['/errorCustomer']);
      }
    );
  }

  sell() {
    console.log("Here in Sell");
    console.log(this.gUnits);
    console.log(this.gUnits.userId);
    this.custServ.sellCustGold(this.gUnits).subscribe(
      (data) => {
        this.stmt = data;
        this.msg = data.msg;
        this.custServ.customerMessage=data.msg;
        if(this.stmt.bool){
          this.router.navigate(['/custDash']);
        }else{
          this.custServ.customerError=data.msg;
          this.router.navigate(['/errorCustomer']);
        }
        
      },
      (error)=>{
       this.custServ.customerError=error;
        this.router.navigate(['/errorCustomer']);
      }
    );

  }

}
