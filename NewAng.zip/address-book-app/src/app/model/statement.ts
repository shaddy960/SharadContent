export class Statement{
    public bool:Boolean;
	public  msg:String;
}