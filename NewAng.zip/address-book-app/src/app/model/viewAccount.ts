export class ViewAccount{
    public accNum:Number;
	public currentBalance:Number;
}