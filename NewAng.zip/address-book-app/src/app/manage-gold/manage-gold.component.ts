import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../service/bank-service.service';
import {  Units } from '../model/units';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-gold',
  templateUrl: './manage-gold.component.html',
  styleUrls: ['./manage-gold.component.css']
})
export class ManageGoldComponent implements OnInit {

  gUnits:Units;
  prmsg:String;
  constructor(private service:BankServiceService, private router:Router) { 
    this.gUnits=new Units();
    this.prmsg="Priyanka";
  }

  ngOnInit() {
  }
  
  updateGPrice(){
    
    console.log(this.gUnits);
    this.service.updateGPrice(this.gUnits).subscribe(
      (data)=>{
        this.prmsg=data.msg
      },
      
    (err)=>{
      this.service.bankError=err.msg;
      this.router.navigate(['/errorBank']);
    }

      );

    
  }

}
