import { Component, OnInit } from '@angular/core';
import { BankMutualFund } from '../model/bankmutualfund';
import { BankServiceService } from '../service/bank-service.service';
import { Output } from '../model/output';
import { Router } from '@angular/router';


@Component({
  selector: 'app-remove-mf',
  templateUrl: './remove-mf.component.html',
  styleUrls: ['./remove-mf.component.css']
})
export class RemoveMfComponent implements OnInit {

  bankmut:BankMutualFund[];
  bank:BankMutualFund;
  msg:String;
  out:Output;
  show:boolean;
  constructor(private banksrv:BankServiceService, private router:Router) { 
    this.bankmut=[];
    this.out=new Output();
    this.msg="Priyanka";
    this.bank= new BankMutualFund;
    this.show=false;
    
  }

  ngOnInit() {
    this.getMf();
  }
  getMf(){
    if(this.bank.expiryDate==null){
      console.log(this.bank.expiryDate);
      this.show=true;
      console.log("works");
      
    }
    else{
      this.show=false;
    }
    console.log("works1");
    this.banksrv.getAllMfs().subscribe(
      
      (data)=>this.bankmut=data
    );
  }
  removeMf(){
    console.log("aadsf");
    
    this.banksrv.removeMf(this.out).subscribe(
     
      (data)=>{
        this.msg=data.msg;
        if(data.bool){
          this.banksrv.bankMessage=data.msg;
          this.router.navigate(['/bank']);
        }else{
          this.banksrv.bankMessage=data.msg;
          this.router.navigate(['/errorBank']);
        }
      },
      
      (err)=>{
        this.banksrv.bankError=err.msg;
        this.router.navigate(['/errorBank']);
      }
    );
  }

}
