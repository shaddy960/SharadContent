import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageSilverComponent } from './manage-silver.component';

describe('ManageSilverComponent', () => {
  let component: ManageSilverComponent;
  let fixture: ComponentFixture<ManageSilverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageSilverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageSilverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
