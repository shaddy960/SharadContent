import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { CustomerService } from '../service/customer.service';
import { AuthenticationService } from '../service/authentication.service';
import { Statement } from '../model/statement';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: User;
  stmt: Statement;

  message: any;
  constructor(private loginservice: AuthenticationService, private router:Router) {
    this.user = new User();
    this.stmt=new Statement();
    this.message = "Hello";
  }

  ngOnInit() {
    this.stmt.bool=false;
  }

  verify() {
    this.loginservice.authenticate(this.user).subscribe(
      (data) => {this.stmt = data ;
      if (this.stmt.bool) {
        this.loginservice.authenticateUser(this.user.userId);
        this.message = this.user.userId;
        this.router.navigate(['/custDash']);
     } else{
     // this.loginservice.customerError=data.msg;
      this.router.navigate(['/errorCustomer']);
    }
    
  },
  (error)=>{
  // this.custServ.customerError=error;
    this.router.navigate(['/errorCustomer']);
  }
    );
    console.log(this.stmt.bool);
   

  }
}

