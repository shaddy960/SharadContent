import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-customer-dashboard',
  templateUrl: './customer-dashboard.component.html',
  styleUrls: ['./customer-dashboard.component.css']
})
export class CustomerDashboardComponent implements OnInit {
  message:String;
  constructor(private custSrv:CustomerService,private router:Router) { 

  }

  ngOnInit() {
    this.message=this.custSrv.customerMessage;
  }
  
  onInvestment():void{ 
    this.router.navigate(['/viewInvestment']);  
  }
  onTransactions():void{
    this.router.navigate(['/viewTransactions']); 
  }
  onGold():void{
    this.router.navigate(['/custGold']); 
  }
  onSilver():void{
    this.router.navigate(['/custSil']); 
  }
  onDirectIn():void{
    this.router.navigate(['investDirect']); 
  }
  onSipIn():void{
    this.router.navigate(['/investSip']); 
  }
  onAcc():void{
    this.router.navigate(['/linkMyacc']); 
  }
  onDirectWith():void{
    this.router.navigate(['/withdrawDir']); 
  }
  onSipWith():void{
    this.router.navigate(['/withdrawSip']); 
  }

}
