import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateMinAmtSipComponent } from './update-min-amt-sip.component';

describe('UpdateMinAmtSipComponent', () => {
  let component: UpdateMinAmtSipComponent;
  let fixture: ComponentFixture<UpdateMinAmtSipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateMinAmtSipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateMinAmtSipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
