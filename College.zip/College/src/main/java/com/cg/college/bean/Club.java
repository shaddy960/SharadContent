package com.cg.college.bean;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Club {
	@Id
	private long clubId;
	private String clubName;
	@OneToMany
	private Set<Student> students;
	
	public Club(long clubId, String clubName) {
		super();
		this.clubId = clubId;
		this.clubName = clubName;
	}
	public long getClubId() {
		return clubId;
	}
	public void setClubId(long clubId) {
		this.clubId = clubId;
	}
	public String getClubName() {
		return clubName;
	}
	public void setClubName(String clubName) {
		this.clubName = clubName;
	}
	public Club() {
		
	}
	
	
	
}
