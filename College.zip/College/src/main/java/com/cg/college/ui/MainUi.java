package com.cg.college.ui;

import com.cg.college.service.ColleggeService;

public class MainUi {

	public static void main(String[] args) {
		ColleggeService cg=new ColleggeService();
		
			cg.addStudent();
		
		

	}

}
