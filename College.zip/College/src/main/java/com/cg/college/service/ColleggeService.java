package com.cg.college.service;

import java.time.LocalDate;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.college.bean.Club;
import com.cg.college.bean.Course;
import com.cg.college.bean.Professor;
import com.cg.college.bean.Student;

public class ColleggeService {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("Sharad");
	EntityManager em=emf.createEntityManager();
	
	
	public Student addStudent() {
		
		Scanner sc=new Scanner(System.in);
		Student student=new Student();
		System.out.println("Enter Student id");
		student.setId(sc.next());
		System.out.println("Enter fname");
		student.setFname(sc.next());
		System.out.println("Enter lname");
		student.setLname(sc.next());
		System.out.println("Enter Fees");
		student.setFees(sc.nextDouble());		
		student.setDateOfJoining(LocalDate.now());
		student.setClub(addClub());
		em.getTransaction().begin();
		em.persist(student);
		em.getTransaction().commit();
		sc.close();
		return student;
	}
	
	
	public Course addCourse() {
		Scanner sc=new Scanner(System.in);
		Course course =new Course();
		System.out.println("Enter courseID");
		course.setCourseId(sc.next());
		System.out.println("Enter Course Name");
		course.setCourseName(sc.next());
		System.out.println("Enter EmpId of Professor");
		course.setProf(new Professor(sc.next()));
		em.getTransaction().begin();
		em.persist(course);
		em.getTransaction().commit();
		sc.close();
		return course;
	}
	
	public Club addClub() {
		Club cl=new Club();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter club ID ");
		cl.setClubId(sc.nextLong());
		System.out.println("Enter name of club");
		cl.setClubName(sc.next());
		sc.close();
		return cl;
	}
	
	
	public Professor addProfessor() {
		Scanner sc=new Scanner(System.in);
		Professor prof=new Professor();
		prof.setEmpId(sc.next());
		em.getTransaction().begin();
		em.persist(prof);
		em.getTransaction().commit();
		return prof;
	}
}
