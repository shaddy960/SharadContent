package com.cg.college.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity
public class Professor {
	@Id
	private String empId;
	@OneToOne
	private Course course;
	
	
	public Professor() {
		super();
	}
	public Professor(String empId) {
		super();
		this.empId = empId;
		
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	
}
