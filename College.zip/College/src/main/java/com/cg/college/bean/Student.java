package com.cg.college.bean;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
@Entity
public class Student {
	@Id
	private String id;
	@Column(name="First_name", length = 50)
	private String fname;
	@Column(name="Last_name", length = 50)
	private String lname;	
	private LocalDate dateOfJoining;
	@Column(precision = 2)
	private double fees;
	@Column(name="Courses_opted")@ManyToMany(cascade = CascadeType.PERSIST)
	private Set<Course> courseSet;
	@OneToOne(cascade = CascadeType.PERSIST)
	private Club club;
	
	public Student() {
		super();
	}

	public Student(String id, String fname, String lname, double fees, Set<Course> courseSet, Club club) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.fees = fees;
		this.courseSet = courseSet;
		this.club = club;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}
	
	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public Set<Course> getCourseSet() {
		return courseSet;
	}

	public void setCourseSet(Set<Course> courseSet) {
		this.courseSet = courseSet;
	}

	public Club getClub() {
		return club;
	}

	public void setClub(Club club) {
		this.club = club;
	}

	
	
	
}
