create table gold_price(update_date DATE PRIMARY KEY,gold_price number(10,2) NOT NULL);

insert into gold_price values('15-OCT-2019',4000.00);

insert into gold_price values('16-OCT-2019',3800.00);
