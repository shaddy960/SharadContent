package com.cg.ibs.investment.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.CustomerService;

@RestController
public class BankController {
	
	@Autowired
	private CustomerService customerService;
	@Autowired
	private BankService bankService;
	
	@PostMapping("/bankLogin/{userId}/{password}")
	public ResponseEntity<String> bankLogin(@PathVariable String userId, @PathVariable String password){
		Boolean status = null;
		ResponseEntity<String> entity=new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		try {
			status = bankService.validateBank(userId, password);
			if(status) {
				entity= new ResponseEntity<>("welcome",HttpStatus.OK);
			}else {
				entity=new ResponseEntity<>("Invalid Username or Password",HttpStatus.UNAUTHORIZED);
			}
		} catch (IBSException e) {
			entity=new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST); 
		}
		return entity;
	}
	
	@GetMapping("/viewGPrice")
	public ResponseEntity<Double> viewGPrice(){
		ResponseEntity<Double> entity=new ResponseEntity<Double>(HttpStatus.BAD_REQUEST);
		try {
			entity= new ResponseEntity<>(customerService.viewGoldPrice() ,HttpStatus.OK );
		} catch (IBSException e) {
			entity=new ResponseEntity<Double>(HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	@GetMapping("/viewSPrice")
	public ResponseEntity<Double> viewSPrice(){
		ResponseEntity<Double> entity=new ResponseEntity<Double>(HttpStatus.BAD_REQUEST);
		try {
			entity= new ResponseEntity<>(customerService.viewSilverPrice() ,HttpStatus.OK );
		} catch (IBSException e) {
			entity= new ResponseEntity<>(HttpStatus.BAD_REQUEST );
		}
		return entity;
	}
	
	@PostMapping("/updateGPrice/{gPrice}")
	public ResponseEntity<String> updateGPrice(@PathVariable Double gPrice){
		ResponseEntity<String> entity = null;
		try {
			Boolean result;
			result = bankService.updateGoldPrice(gPrice);
			if(result) {
				 entity = new ResponseEntity<>("Gold Price updated successfully",HttpStatus.OK);
			}else {
				entity =  new ResponseEntity<>("Gold Price is already updated today",HttpStatus.OK);
			}
		} catch (IBSException e) {
			entity=new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST); 
		}
		return entity;
	}
	
	@PostMapping("/updateSPrice/{sPrice}")
	public ResponseEntity<String> updateSPrice(@PathVariable Double sPrice){
		ResponseEntity<String> entity = null;
		try {
			Boolean result;
			result = bankService.updateSilverPrice(sPrice);
			if(result) {
				 entity = new ResponseEntity<>("Silver Price updated successfully",HttpStatus.OK);
			}else {
				entity =  new ResponseEntity<>("Silver Price is already updated today",HttpStatus.OK);
			}
		} catch (IBSException e) {
			entity=new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST); 
		}
		return entity;
	}

	@GetMapping("/viewMf")
	public ResponseEntity<HashMap<Integer, BankMutualFund>> viewMf(){
		HashMap<Integer, BankMutualFund> mutualFunds = null;
		ResponseEntity<HashMap<Integer, BankMutualFund>> entity=null;
		try {
			mutualFunds = customerService.viewMFPlans();
			entity=new ResponseEntity<HashMap<Integer,BankMutualFund>>(mutualFunds,HttpStatus.OK);
		} catch (IBSException e) {
			entity=new ResponseEntity<HashMap<Integer,BankMutualFund>>(HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	@PostMapping("/addMf")
	public ResponseEntity<String> addMf(@RequestBody BankMutualFund bankMutualFund){
		ResponseEntity<String> entity=new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		try {
			bankService.addMF(bankMutualFund);
			entity=new ResponseEntity<String>("You successfully added a Mutual Fund", HttpStatus.OK);
		} catch (IBSException e) {
			entity=new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	@PutMapping("/updateNav/{mfPlanId}/{nav}")
	public ResponseEntity<String> updateNav(@PathVariable Integer mfPlanId, @PathVariable Double nav){
		ResponseEntity<String> entity=new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		try {
			bankService.updateNav(mfPlanId, nav);
			entity=new ResponseEntity<>("You successfully updated Nav of the Mutual Fund plan",HttpStatus.OK);
		} catch (IBSException e) {
			entity=new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	@PutMapping("/updateSipStatus/{mfPlanId}/{sipStatus}")
	public ResponseEntity<String> updateSipStatus(@PathVariable Integer mfPlanId, @PathVariable Boolean sipStatus){
		ResponseEntity<String> entity=new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		try {
			bankService.updateSipStatus(mfPlanId, sipStatus);
			entity= new ResponseEntity<>("You successfully updated SIP status of the selected Mutual Fund",HttpStatus.OK);
		} catch (IBSException e) {
			entity=new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	@PutMapping("/updateDirStatus/{mfPlanId}/{dirStatus}")
	public ResponseEntity<String> updateDirStatus(@PathVariable Integer mfPlanId, @PathVariable Boolean dirStatus){
		ResponseEntity<String> entity=new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		try {
			bankService.updateDirStatus(mfPlanId, dirStatus);
			entity=new ResponseEntity<>("You successfully updated DIR status of the selected Mutual Fund",HttpStatus.OK);
		} catch (IBSException e) {
			entity=new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	@PutMapping("/updateMinDirAmt/{mfPlanId}/{minAmtDir}")
	public ResponseEntity<String> updateMinDirAmt(@PathVariable Integer mfPlanId, @PathVariable Double minAmtDir){
		ResponseEntity<String> entity=new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		try {
			bankService.updateMinDir(mfPlanId, minAmtDir);
			entity=new ResponseEntity<>("You successfully updated minimum amount for Direct Investment for the selected Mutual Fund",HttpStatus.OK);
		} catch (IBSException e) {
			entity=new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	@PutMapping("/updateMinSipAmt/{mfPlanId}/{minAmtSip}")
	public ResponseEntity<String> updateMinSipAmt(@PathVariable Integer mfPlanId, @PathVariable Double minAmtSip){
		ResponseEntity<String> entity=new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		
		try {
			bankService.updateMinSip(mfPlanId, minAmtSip);
			entity=new ResponseEntity<>("You successfully updated minimum amount for SIP Investment for the selected Mutual Fund",HttpStatus.OK);
		} catch (IBSException e) {
			entity=new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	@PatchMapping("/removeMf/{mfPlanId}")
	public ResponseEntity<String> removeMf(@PathVariable Integer mfPlanId){
		ResponseEntity<String> entity=new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		try {
			bankService.removeMF(mfPlanId);
			entity=new ResponseEntity<>("You successfully removed the Mutual Fund plan",HttpStatus.OK);
		} catch (IBSException e) {
			entity=new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
}
