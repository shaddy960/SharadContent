package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeSet;

import com.cg.ibs.common.bean.AccountBean;
import com.cg.ibs.common.bean.CustomerBean;
import com.cg.ibs.common.bean.TransactionBean;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.IBSException;

public interface CustomerDao {
	double viewGoldPrice() throws IBSException ;

	double viewSilverPrice() throws IBSException;

	InvestmentBean viewInvestments(String userId) throws IBSException;

	HashMap<Integer, BankMutualFund> viewMF() throws IBSException;

	

	public void updateUnits(String uci, double gunits, InvestmentBean investmentBean, int choice) throws IBSException;

	public void addMFInvestments(double mfAmount, int mfId, InvestmentBean investmentBean) throws IBSException;

	public void withdrawMF(String userId, MutualFund mutualFund, InvestmentBean investmentBean) throws IBSException;

	public TreeSet<TransactionBean> getTransactions(String userId) throws IBSException;

	CustomerBean getCustomer(String userid) throws IBSException;

	void linkNewAccount(BigInteger accountNumber, String uci) throws IBSException;
	public ArrayList<AccountBean> getAccountsByUci(String uci) throws IBSException;

	String getUcibyUseriD(String userId) throws IBSException;
	
	

}