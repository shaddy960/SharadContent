package com.cg.ibs.investment.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.cg.ibs.common.bean.AccountBean;
import com.cg.ibs.common.bean.CustomerBean;
import com.cg.ibs.common.bean.TransactionBean;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.dao.CustomerDao;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.exception.ErrorMessages;
import com.cg.ibs.investment.exception.IBSException;

public class CustomerServiceImpl implements CustomerService {
	private static final Logger log = Logger.getLogger(CustomerServiceImpl.class);

	// Declaring an object of Client DAO
	CustomerDao clientdao = new InvestmentDaoImpl();

	// To view Mutual Fund plans of the customer
	@Override
	public HashMap<Integer, BankMutualFund> viewMFPlans() throws IBSException {
		log.info("Mutual Fund plans returned for viewing");
		return (clientdao.viewMF());

	}

	// To view Gold price
	@Override
	public double viewGoldPrice() throws IBSException {
		log.info("Gold Price returned for viewing");
		return (clientdao.viewGoldPrice());

	}

	// To view Silver price
	@Override
	public double viewSilverPrice() throws IBSException {
		log.info("Silver Price returned for viewing");
		return (clientdao.viewSilverPrice());

	}

	// To buy gold
	@Override
	public void buyGold(double gunits, String userid) throws IBSException {
		String uci = clientdao.getUcibyUseriD(userid);
		if (gunits > 0) {
			InvestmentBean investmentBean = clientdao.viewInvestments(uci);
			if (investmentBean.getBalance() >= gunits * clientdao.viewGoldPrice()) {
				clientdao.updateUnits(uci, gunits, investmentBean, 1);
				log.info("Gold bought");

			} else {
				log.error(ErrorMessages.INSUFF_BALANCE_MESSAGE);
				throw new IBSException(ErrorMessages.INSUFF_BALANCE_MESSAGE);
			}

		} else {
			log.error("Invalid units");
			throw new IBSException(ErrorMessages.INVALID_UNITS_MESSAGE);

		}
	}

	// To Sell Gold
	@Override
	public void sellGold(double gunits, String userId) throws IBSException {
		String uci = clientdao.getUcibyUseriD(userId);
		InvestmentBean investmentBean = clientdao.viewInvestments(uci);
		if (gunits > 0) {
			if (gunits < investmentBean.getGoldunits()) {
				clientdao.updateUnits(uci, gunits, investmentBean, 2);
				log.info("Gold sold");

			} else {
				log.error(ErrorMessages.INSUFF_BALANCE_MESSAGE);
				throw new IBSException(ErrorMessages.INSUFF_BALANCE_MESSAGE);
			}

		} else {
			log.error(ErrorMessages.INVALID_UNITS_MESSAGE);
			throw new IBSException(ErrorMessages.INVALID_UNITS_MESSAGE);
		}

	}

	// To buy Silver
	@Override
	public void buySilver(double sunits, String userId) throws IBSException {
		String uci = clientdao.getUcibyUseriD(userId);
		if (sunits > 0) {
			InvestmentBean investmentBean = clientdao.viewInvestments(uci);
			if (investmentBean.getBalance() >= sunits * clientdao.viewSilverPrice()) {

				clientdao.updateUnits(uci, sunits, investmentBean, 3);
				log.info("Silver bought");

			} else {
				log.error(ErrorMessages.INSUFF_BALANCE_MESSAGE);
				throw new IBSException(ErrorMessages.INSUFF_BALANCE_MESSAGE);
			}

		} else {
			log.error(ErrorMessages.INVALID_UNITS_MESSAGE);
			throw new IBSException(ErrorMessages.INVALID_UNITS_MESSAGE);
		}

	}

	// To Sell Silver
	@Override
	public void sellSilver(double sunits, String userId) throws IBSException {
		String uci = clientdao.getUcibyUseriD(userId);
		InvestmentBean investmentBean = clientdao.viewInvestments(uci);
		if (sunits > 0) {
			if (sunits < investmentBean.getSilverunits()) {
				clientdao.updateUnits(uci, sunits, investmentBean, 4);
				log.info("Silver Sold");
			} else {
				log.error(ErrorMessages.INSUFF_BALANCE_MESSAGE);
				throw new IBSException(ErrorMessages.INSUFF_BALANCE_MESSAGE);
			}

		} else {
			log.error(ErrorMessages.INVALID_UNITS_MESSAGE);
			throw new IBSException(ErrorMessages.INVALID_UNITS_MESSAGE);
		}
	}

	// To invest in Mutual Funds
	@Override
	public void investMF(double mfAmount, String userId, Integer mfId) throws IBSException {
		String uci = clientdao.getUcibyUseriD(userId);
		if (mfAmount > 0) {
			if (clientdao.viewMF().containsKey(mfId)) {
				InvestmentBean investmentBean = null;

				investmentBean = clientdao.viewInvestments(uci);

				if (investmentBean.getBalance() >= mfAmount) {
					clientdao.addMFInvestments(mfAmount, mfId, investmentBean);
					log.info("Investment in MF successful");

				} else {
					log.error(ErrorMessages.INSUFF_BALANCE_MESSAGE);
					throw new IBSException(ErrorMessages.INSUFF_BALANCE_MESSAGE);
				}
			} else {
				log.error(ErrorMessages.INVALID_DETAILS_MESSAGE);
				throw new IBSException(ErrorMessages.INVALID_DETAILS_MESSAGE);
			}
		} else {
			log.error(ErrorMessages.INVALID_AMOUNT_MESSAGE);
			throw new IBSException(ErrorMessages.INVALID_AMOUNT_MESSAGE);
		}
	}

	// To withdraw from Mutual Funds
	@Override
	public void withdrawMF(String userId, MutualFund mutualFund) throws IBSException {
		String uci = clientdao.getUcibyUseriD(userId);
		if (clientdao.viewInvestments(uci) != null) {
			InvestmentBean investmentBean = clientdao.viewInvestments(uci);
			clientdao.withdrawMF(uci, mutualFund, investmentBean);
			log.info("MF withdrawn successfully");

		} else {
			log.error(ErrorMessages.INVALID_DETAILS_MESSAGE);
			throw new IBSException(ErrorMessages.INVALID_DETAILS_MESSAGE);
		}
	}

	// To view Investments of a customer
	/**
	 * 
	 * 
	 */
	@Override
	public InvestmentBean viewInvestments(String userid) throws IBSException {
		String uci = clientdao.getUcibyUseriD(userid);
		if (clientdao.viewInvestments(uci) != null) {
			log.info("ClientDao object exists");
			log.info("Investments received");
			return clientdao.viewInvestments(uci);

		} else {
			log.error("no such account exists" + ErrorMessages.INVALID_ACCOUNT_MESSAGE);
			throw new IBSException(ErrorMessages.INVALID_ACCOUNT_MESSAGE);

		}

	}

	// To validate login details of a customer
	@Override
	public boolean validateCustomer(String userId, String password) throws IBSException {
		CustomerBean cs = clientdao.getCustomer(userId);
		try {
			String uci = clientdao.getUcibyUseriD(userId);
			if (cs != null && userId.equals(cs.getUserId())) {

				String correctPassword = cs.getPassword();
				if (password.equals(correctPassword)) {
					log.info("Customer Validated Successfully");
					return true;
				}

			}
		} catch (IBSException e) {
			log.error(ErrorMessages.INVALID_DETAILS_MESSAGE);
			throw new IBSException(ErrorMessages.INVALID_DETAILS_MESSAGE);
		}
		return false;

	}

	// To generate transaction history of a customer
	@Override
	public TreeSet<TransactionBean> getTransactions(String userId) throws IBSException {
		log.info("Transactions returned successfully");
		return clientdao.getTransactions(userId);
	}

	public void viewMyAccounts(ArrayList<AccountBean> accBean) {
		int i = 0;
		for (AccountBean accountBean : accBean) {
			System.out.println(i + " " + accountBean.getAccountNumber() + " " + accountBean.getCurrentBalance() + " "
					+ accountBean.getUci());
			i++;
		}
		log.info("List of Accounts Recieved");

	}

	public AccountBean linkMyAccount(ArrayList<AccountBean> accBean, int i) {
		log.info("Account linked by service");

		return accBean.get(i);
	}

	@Override
	public ArrayList<AccountBean> getAccountList(String userId) throws IBSException {
		String uci = clientdao.getUcibyUseriD(userId);
		ArrayList<AccountBean> accountList = clientdao.getAccountsByUci(uci);
		log.info("List of accounts recieved");
		return accountList;

	}

	@Override
	public void linkMyAccount(BigInteger accountNumber, String userId) throws IBSException {
		String uci = clientdao.getUcibyUseriD(userId);
		clientdao.linkNewAccount(accountNumber, uci);
		log.info("Account linked by service");

	}

}
