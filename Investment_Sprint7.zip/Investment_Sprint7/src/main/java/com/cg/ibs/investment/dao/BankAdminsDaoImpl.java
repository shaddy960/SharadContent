package com.cg.ibs.investment.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;


import com.cg.ibs.investment.bean.Banker;

@Repository("baObject")
public class BankAdminsDaoImpl  implements BankAdminsDao{
	@PersistenceContext
	private EntityManager entityManager;

	
	public Banker addBankAdmins(Banker bank) {
		entityManager.persist(bank);
		return bank;
	}

	public Banker getBankById(String userId) {
		System.out.println(userId);
		return entityManager.find(Banker.class, userId);
	}

}
