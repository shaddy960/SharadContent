package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.investment.bean.Transaction;

public interface TransactionDao {

	Transaction addTransaction(Transaction trxn);

	List<Transaction> getAllTransactionByAccno(BigInteger accno);

}
