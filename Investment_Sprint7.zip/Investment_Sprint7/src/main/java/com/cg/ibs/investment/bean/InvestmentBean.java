package com.cg.ibs.investment.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="Investments")
public class InvestmentBean implements Serializable {
	
	@Id
	private BigInteger UCI;
	@OneToOne
	@JoinColumn(name = "UCI")
	@MapsId
	private Customer customer;

	@Column(name="Gold_Units",precision = 2)
	private Double goldunits;

	@Column(name = "Silver_Units",precision = 2)
	private Double silverunits;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "inv")
	private Set<MutualFund> funds;
	@OneToOne(cascade= CascadeType.ALL)
	private Account account;

	public InvestmentBean() {
		super();
	}

	public BigInteger getUCI() {
		return UCI;
	}

	public void setUCI(BigInteger bigInteger) {
		UCI = bigInteger;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Double getGoldunits() {
		return goldunits;
	}

	public void setGoldunits(Double goldunits) {
		this.goldunits = goldunits;
	}

	public Double getSilverunits() {
		return silverunits;
	}

	public void setSilverunits(Double silverunits) {
		this.silverunits = silverunits;
	}

	

	

	public Set<MutualFund> getFunds() {
		return funds;
	}

	public void setFunds(Set<MutualFund> funds) {
		this.funds = funds;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

}
