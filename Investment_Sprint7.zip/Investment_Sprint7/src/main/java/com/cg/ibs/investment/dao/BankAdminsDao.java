package com.cg.ibs.investment.dao;


import com.cg.ibs.investment.bean.Banker;

public interface BankAdminsDao {
	Banker addBankAdmins(Banker id);

	Banker getBankById(String id);

}
