import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../service/bank-service.service';
import {  Units } from '../model/units';

@Component({
  selector: 'app-manage-gold',
  templateUrl: './manage-gold.component.html',
  styleUrls: ['./manage-gold.component.css']
})
export class ManageGoldComponent implements OnInit {

  gUnits:Units;
  prmsg:String;
  constructor(private service:BankServiceService) { 
    this.gUnits=new Units();
    this.prmsg="Priyanka";
  }

  ngOnInit() {
  }
  
  updateGPrice(){
    
    console.log(this.gUnits);
    this.service.updateGPrice(this.gUnits).subscribe(
      (data)=>this.prmsg=data.msg
    );

    
  }

}
