import { Component, OnInit } from '@angular/core';
import { BankMutualFund } from '../model/bankmutualfund';
import { BankServiceService } from '../service/bank-service.service';
import { Output } from '../model/output';
import { Statement } from '../model/statement';
import { Router } from '@angular/router';
import { BankMenuComponent } from '../bank-menu/bank-menu.component';

@Component({
  selector: 'app-update-dir-status',
  templateUrl: './update-dir-status.component.html',
  styleUrls: ['./update-dir-status.component.css']
})
export class UpdateDirStatusComponent implements OnInit {
  bankmut:BankMutualFund[];
  msg:String;
  out:Output;
  stmt:Statement;
 
  constructor(private banksrv:BankServiceService,private router:Router) { 
    this.bankmut=[];
   
    this.stmt=new Statement();
    this.out=new Output();
    this.msg="Priyanka";
    
  }

  ngOnInit() {
    this.getMf();
  }
  getMf(){
    this.banksrv.getAllMfs().subscribe(
      (data)=>this.bankmut=data
    );
  }
  updateDir(){
    this.banksrv.updateDirStatus(this.out).subscribe(
      (data)=>{
        this.msg=data.msg;
        this.banksrv.bankMessage=data.msg;
        this.stmt.bool=data.bool;
        if(this.stmt.bool){         
          this.router.navigate(['/Bank']);
        }else{

        }
      }
     
    );
  }

}
