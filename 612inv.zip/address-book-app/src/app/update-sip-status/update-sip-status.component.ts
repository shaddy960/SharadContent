import { Component, OnInit } from '@angular/core';
import { BankMutualFund } from '../model/bankmutualfund';
import { BankServiceService } from '../service/bank-service.service';
import { Output } from '../model/output';
import { Router } from '@angular/router';


@Component({
  selector: 'app-update-sip-status',
  templateUrl: './update-sip-status.component.html',
  styleUrls: ['./update-sip-status.component.css']
})
export class UpdateSipStatusComponent implements OnInit {

  bankmut:BankMutualFund[];
  msg:String;
  out:Output;
  constructor(private banksrv:BankServiceService, private router:Router) { 
    this.bankmut=[];
    this.out=new Output();
    this.msg="Priyanka";
    
  }

  ngOnInit() {
    this.getMf();
  }
  getMf(){
    this.banksrv.getAllMfs().subscribe(
      (data)=>this.bankmut=data
    );
  }
  updateSip(){
    this.banksrv.updateSipStatus(this.out).subscribe(
      (data)=>{
        this.msg=data.msg;
        this.banksrv.bankMessage=data.msg;
        this.out.bool=data.bool;
        if(this.out.bool){         
          this.router.navigate(['/Bank']);
        }else{

        }
      }
    );
  }

}
