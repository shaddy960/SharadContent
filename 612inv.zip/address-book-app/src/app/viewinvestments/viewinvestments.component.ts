import { Component, OnInit } from '@angular/core';
import { ViewInvestment } from '../model/viewInvestment';
import { CustomerService } from '../service/customer.service';
import {MutualFund} from '../model/mutualfund';

@Component({
  selector: 'app-viewinvestments',
  templateUrl: './viewinvestments.component.html',
  styleUrls: ['./viewinvestments.component.css']
})
export class ViewinvestmentsComponent implements OnInit {
  num:Number;
  viewInv:ViewInvestment;
  DirFunds: MutualFund[];
  SIPFunds: MutualFund[];
  constructor(private custServ:CustomerService) {
    this.viewInv=new ViewInvestment();
 
   }

  ngOnInit() {
    this.load();
  }
  load() {
    this.custServ.getInv().subscribe(
      (data) => {
        this.viewInv = data;
        this.DirFunds=data.dirFunds;
        this.SIPFunds=data.sipfunds;
     
     
      }
    );

   
  }

}
