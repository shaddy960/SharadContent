import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { BankLogin } from '../model/bank-login';
import { Units } from '../model/units';
import { Output } from '../model/output';
import { BankMutualFund } from '../model/bankmutualfund';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class BankServiceService {
  bankMessage:String;
  baseUrl:string;
  baseurl2:string;

  constructor(private http:HttpClient) {
    this.baseUrl =`${environment.baseMwUrl}/bank`;
    this.bankMessage="Welcome to Bank Administration Portal";
   }

   loginBank(user:User):Observable<Output>{
    return this.http.post<Output>(`${this.baseUrl}/bankLogin`,user);
  }
  updateGPrice(units:Units):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateGPrice`,units);
  }
  updateSPrice(units:Units):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateSPrice`,units);
  }
  addMf(bk:BankMutualFund):Observable<Output>{
    return this.http.post<Output>(`${this.baseUrl}/addMf`,bk);
  }
  getAllMfs():Observable<BankMutualFund[]>{

    return this.http.get<BankMutualFund[]>(`${this.baseUrl}/viewMf`);
  }
  updateDirStatus(out:Output):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateDirStatus`,out);
  }
  updateSipStatus(out:Output):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateSipStatus`,out);
  }
  updateDirAmt(out:Output):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateMinDirAmt`,out);
  }
  updateSipAmt(out:Output):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateMinSipAmt`,out);
  }
  updateNav(out:Output):Observable<Output>{
    return this.http.put<Output>(`${this.baseUrl}/updateNav`,out);
  }
  removeMf(out:Output):Observable<Output>{
    return this.http.patch<Output>(`${this.baseUrl}/removeMf`,out);
  }
}
