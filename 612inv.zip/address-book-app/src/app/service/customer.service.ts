import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';
import { ViewInvestment } from '../model/viewInvestment';

  import {Statement} from '../model/statement';
import { Units } from '../model/units';
import { Directdata } from '../model/directdata';
import { BankMutualFund } from '../model/bankmutualfund';
import { MutualFund } from '../model/mutualfund';
import { SipData } from '../model/sipdata';
import { InvestmentTrans } from '../model/investmentTrans';
import { WithdrawDir } from '../model/withdrawdir';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  customerMessage:String;
  baseUrl: string;
  viewInvUrl:string;
  buyGold:string;
  sellGold:string;
  buySilver:string;
  sellSilver:string;
  investDirect:string;
  viewDirPlan:string;
  viewSipPlan:string;
  investSip:string;
  viewTrans:string;
  withdrawDir:string;
  withdrawSip:string;
  result: Observable<String>;
  constructor(private http: HttpClient) { 
    this.baseUrl =`${environment.baseMwUrl}/customer/login`;
    this.viewInvUrl =`${environment.baseMwUrl}/customer/viewMyInvestment`;
    this.buyGold=`${environment.baseMwUrl}/customer/buyGold`;
    this.sellGold=`${environment.baseMwUrl}/customer/sellGold`;
    this.buySilver=`${environment.baseMwUrl}/customer/buySilver`;
    this.sellSilver=`${environment.baseMwUrl}/customer/sellSilver`;
    this.investDirect=`${environment.baseMwUrl}/customer/directInvest`;
    this.viewDirPlan=`${environment.baseMwUrl}/customer/viewDirectMf`;
    this.viewSipPlan=`${environment.baseMwUrl}/customer/viewSipMf`;
    this.investSip=`${environment.baseMwUrl}/customer/investSipMf`;
    this.viewTrans=`${environment.baseMwUrl}/customer/viewTrans`;
    this.withdrawDir=`${environment.baseMwUrl}/customer/withdrawDirMf`;
    this.withdrawSip=`${environment.baseMwUrl}/customer/withdrawSipMf`;
    this.customerMessage="Welcome to Customer DashBoard";
  }

  authenticate(user:User): Observable<Statement>{
 
       return this.http.post<Statement>(this.baseUrl,user);
    

  }
  getInv():Observable<ViewInvestment>{
    return this.http.get<ViewInvestment>(this.viewInvUrl);
  }

  buyCustGold(gunits:Units):Observable<Statement>{
    console.log(gunits.units)
    return this.http.post<Statement>(this.buyGold,gunits);

  }
  sellCustGold(gunits:Units):Observable<Statement>{
    return this.http.post<Statement>(this.sellGold,gunits);
  }

  buyCustSilver(sunits:Units):Observable<Statement>{
    console.log(sunits.units)
    return this.http.post<Statement>(this.buySilver,sunits);

  }
  sellCustSilver(sunits:Units):Observable<Statement>{
    return this.http.post<Statement>(this.sellSilver,sunits);
  }

  investDirectCust(directdata:Directdata):Observable<Statement>{
    return this.http.post<Statement>(this.investDirect,directdata);
  }
  viewDirPlanCust():Observable<BankMutualFund[]>{
    return this.http.get<BankMutualFund[]>(this.viewDirPlan);
  }
  viewSipPlanCust():Observable<BankMutualFund[]>{
    return this.http.get<BankMutualFund[]>(this.viewSipPlan);
  }
  investSipCust(sipdata:SipData):Observable<Statement>{
    return this.http.post<Statement>(this.investSip,sipdata);
  }
  getAllTrans():Observable<InvestmentTrans[]>{
    return this.http.get<InvestmentTrans[]>(this.viewTrans);
  }
  withdrawDirMeth(withdr:WithdrawDir):Observable<Statement>{
    return this.http.post<Statement>(this.withdrawDir, withdr);
  }
  withdrawSipMeth(withsp:WithdrawDir):Observable<Statement>{
    return this.http.post<Statement>(this.withdrawSip, withsp);
  }
  



}
