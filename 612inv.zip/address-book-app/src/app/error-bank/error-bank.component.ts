import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-bank',
  templateUrl: './error-bank.component.html',
  styleUrls: ['./error-bank.component.css']
})
export class ErrorBankComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
