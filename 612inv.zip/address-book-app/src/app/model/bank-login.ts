export class BankLogin {
    userId:String;
    password:String;
}
