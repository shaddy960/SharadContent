export class User{
    public userId:string;
    public password:string;
}