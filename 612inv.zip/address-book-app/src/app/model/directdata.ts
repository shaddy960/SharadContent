export class Directdata{
    public mfPlanId:Number ;
    public mfAmount:Number;
}