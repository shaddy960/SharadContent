import { Component, OnInit } from '@angular/core';
import { BankMutualFund } from '../model/bankmutualfund';
import { BankServiceService } from '../service/bank-service.service';
import { Output } from '../model/output';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-min-amt-dir',
  templateUrl: './update-min-amt-dir.component.html',
  styleUrls: ['./update-min-amt-dir.component.css']
})
export class UpdateMinAmtDirComponent implements OnInit {

  bankmut:BankMutualFund[];
  msg:String;
  out:Output;
  constructor(private banksrv:BankServiceService,private router:Router) { 
    this.bankmut=[];
    this.out=new Output();
    this.msg="Priyanka";
    
  }

  ngOnInit() {
    this.getMf();
  }
  getMf(){
    this.banksrv.getAllMfs().subscribe(
      (data)=>this.bankmut=data
    );
  }
  updateDirAmount(){
 
    this.banksrv.updateDirAmt(this.out).subscribe(
      (data)=>{
        this.msg=data.msg;
        this.banksrv.bankMessage=data.msg;
        this.out.bool=data.bool;
        if(this.out.bool){         
          this.router.navigate(['/Bank']);
        }else{

        }
      }
    );
  }

}
