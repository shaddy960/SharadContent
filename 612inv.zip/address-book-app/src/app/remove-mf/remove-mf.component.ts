import { Component, OnInit } from '@angular/core';
import { BankMutualFund } from '../model/bankmutualfund';
import { BankServiceService } from '../service/bank-service.service';
import { Output } from '../model/output';


@Component({
  selector: 'app-remove-mf',
  templateUrl: './remove-mf.component.html',
  styleUrls: ['./remove-mf.component.css']
})
export class RemoveMfComponent implements OnInit {

  bankmut:BankMutualFund[];
  bank:BankMutualFund;
  msg:String;
  out:Output;
  show:boolean;
  constructor(private banksrv:BankServiceService) { 
    this.bankmut=[];
    this.out=new Output();
    this.msg="Priyanka";
   
   
    
  }

  ngOnInit() {
    this.getMf();
  }
  getMf(){
    if(this.bank.expiryDate==null){
      this.show=true;
      console.log("works");
    }
    else{
      this.show=false;
    }
    console.log("works1");
    this.banksrv.getAllMfs().subscribe(
      
      (data)=>this.bankmut=data
    );
  }
  removeMf(){
    console.log("aadsf");
    
    this.banksrv.removeMf(this.out).subscribe(
     
      (data)=>this.msg=data.msg
    );
  }

}
