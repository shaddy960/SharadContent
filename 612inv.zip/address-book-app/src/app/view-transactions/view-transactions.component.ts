import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { InvestmentTrans } from '../model/investmentTrans';

@Component({
  selector: 'app-view-transactions',
  templateUrl: './view-transactions.component.html',
  styleUrls: ['./view-transactions.component.css']
})
export class ViewTransactionsComponent implements OnInit {
  invTr:InvestmentTrans[];
  constructor(private custSrv:CustomerService) {
    this.invTr=[];
   }

  ngOnInit() {
    this.getAllInvTr();
  }
  getAllInvTr(){
    this.custSrv.getAllTrans().subscribe(
      (data)=>this.invTr=data
    );
  }

}
