import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BankServiceService } from '../service/bank-service.service';

@Component({
  selector: 'app-bank-menu',
  templateUrl: './bank-menu.component.html',
  styleUrls: ['./bank-menu.component.css']
})
export class BankMenuComponent implements OnInit {
  message:String;
  constructor(private router:Router,private bankService:BankServiceService) {

   }

  ngOnInit() {
    this.message=this.bankService.bankMessage;
  }

  gold():void{
    this.router.navigate(['/manageGold']);
  }
  silver():void{
    this.router.navigate(['/manageSilver']);
  }
  mutualFund():void{
    this.router.navigate(['/manageMf']);
  }

}
