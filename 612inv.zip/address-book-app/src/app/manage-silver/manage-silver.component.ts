import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../service/bank-service.service';
import {  Units } from '../model/units';

@Component({
  selector: 'app-manage-silver',
  templateUrl: './manage-silver.component.html',
  styleUrls: ['./manage-silver.component.css']
})
export class ManageSilverComponent implements OnInit {
  sUnits:Units;
  prmsg:String;
  constructor(private service:BankServiceService) { 
    this.sUnits=new Units();
    this.prmsg="Priyanka";
  }

  ngOnInit() {
  }
  
  updateSPrice(){
    
    console.log(this.sUnits);
    this.service.updateSPrice(this.sUnits).subscribe(
      (data)=>this.prmsg=data.msg
    );

    
  }
}
